#include<stdio.h>
#include<stdlib.h>

#define _USE_MATH_DEFINES
#include <math.h>
#include <vector>

#include <IL/il.h>

#ifdef __APPLE__
#include <GLUT/glut.h>
#include <map>

#else
#include <GL/glew.h>
#include <GL/glut.h>
#endif


#include "parser.h"

using namespace std;

vector<Group> grupos;
vector<Light> lights;

float alfa = 0.0f, beta = 0.5f, radius = 100.0f;
float camX, camY, camZ;
vector< vector<float> > p;
float t=0;

float timebase = 0;
int frame = 0;

int mostraOrbita=1, mostraTextura=1, mostraVisao=0; //Boleanos para os menus

float y[3]={0,1,0};


//Variáveis para o background
unsigned int texture;
int imageWidth = 256;
unsigned char *imageData;

std::vector<float> position,normal, texCoord;
GLuint buffers[3];


//Buffers das primitivas
typedef struct primitiveBuffer{
    string model;
    GLuint buffers[3];
}primitiveBuffer;

vector<primitiveBuffer> primitiveBuffers;

//Texturas
typedef struct loadedTexture{
    string texture;
    GLuint id;
}loadedTexture;

vector<loadedTexture> loadedTextures;



void multMatrixVector(float *m, float *v, float *res) {

    for (int j = 0; j < 4; ++j) {
        res[j] = 0;
        for (int k = 0; k < 4; ++k) {
            res[j] += v[k] * m[j * 4 + k];
        }
    }

}

void spherical2Cartesian() {

    camX = radius * cos(beta) * sin(alfa);
    camY = radius * sin(beta);
    camZ = radius * cos(beta) * cos(alfa);
}

// returns res = a x b
void cross(float *a, float *b, float *res) {

    res[0] = a[1]*b[2] - a[2]*b[1];
    res[1] = a[2]*b[0] - a[0]*b[2];
    res[2] = a[0]*b[1] - a[1]*b[0];
}

// normalizes vector a
void normalize(float *a) {

    float l = sqrt(a[0]*a[0] + a[1] * a[1] + a[2] * a[2]);
    a[0] = a[0]/l;
    a[1] = a[1]/l;
    a[2] = a[2]/l;
}

float h(int i, int j) {

    return(imageData[i*imageWidth + j] * 0.2f);
}

void computeNormal(int i, int j) {

    // fill the normal vector with the normal for vertex at grid location (i,j)
    float v1[3];
    float v2[3];
    float *res1 = (float*)malloc(sizeof(float)*3);

    v1[0] = 0;
    v1[1] = h(i,j+1) - h(i,j-1);
    v1[2] = 2;
    v2[0] = 2;
    v2[1] = h(i+1,j)-h(i-1,j);
    v2[2] = 0;

    cross(v1,v2,res1);
    normalize(res1);

    normal.push_back(res1[0]);
    normal.push_back(res1[1]);
    normal.push_back(res1[2]);
}

void buildRotMatrix(float *x, float *y, float *z, float *m) {

    m[0] = x[0]; m[1] = x[1]; m[2] = x[2]; m[3] = 0;
    m[4] = y[0]; m[5] = y[1]; m[6] = y[2]; m[7] = 0;
    m[8] = z[0]; m[9] = z[1]; m[10] = z[2]; m[11] = 0;
    m[12] = 0; m[13] = 0; m[14] = 0; m[15] = 1;
}

void getCatmullRomPoint(float t, vector<float> p0, vector<float> p1, vector<float> p2, vector<float> p3, float *pos, float *deriv) {
    // catmull-rom matrix
    float m[4][4] = {	{-0.5f,  1.5f, -1.5f,  0.5f},
                         { 1.0f, -2.5f,  2.0f, -0.5f},
                         {-0.5f,  0.0f,  0.5f,  0.0f},
                         { 0.0f,  1.0f,  0.0f,  0.0f}};

    float vectort[4]= {pow(t,3),pow(t,2),t,1};

    float vectord[4]= {3*pow(t,2),2*t,1,0};

    float px[4]={p0[0],p1[0],p2[0],p3[0]};
    float py[4]={p0[1],p1[1],p2[1],p3[1]};
    float pz[4]={p0[2],p1[2],p2[2],p3[2]};

    float ax[4];
    float ay[4];
    float az[4];

    multMatrixVector((float *)m,px,ax);

    pos[0]= vectort[0]*ax[0] + vectort[1]*ax[1] +vectort[2]*ax[2] + vectort[3]*ax[3];

    deriv[0]= vectord[0]*ax[0] + vectord[1]*ax[1] +vectord[2]*ax[2]+ vectord[3]*ax[3];

    multMatrixVector((float *)m,py,ay);

    pos[1]= vectort[0]*ay[0] + vectort[1]*ay[1] +vectort[2]*ay[2]+ vectort[3]*ay[3];

    deriv[1]= vectord[0]*ay[0] + vectord[1]*ay[1] +vectord[2]*ay[2]+ vectord[3]*ay[3];

    multMatrixVector((float *)m,pz,az);

    pos[2]= vectort[0]*az[0] + vectort[1]*az[1] +vectort[2]*az[2]+ vectort[3]*az[3];

    deriv[2]= vectord[0]*az[0] + vectord[1]*az[1] +vectord[2]*az[2]+ vectord[3]*az[3];

}

// given  global t, returns the point in the curve
void getGlobalCatmullRomPoint(float gt, float *pos, float *deriv, int POINT_COUNT) {

    float t = gt * POINT_COUNT; // this is the real global t
    int index = floor(t);  // which segment
    t = t - index; // where within  the segment

    // indices store the points
    int indices[4];
    indices[0] = (index + POINT_COUNT-1)%POINT_COUNT;
    indices[1] = (indices[0]+1)%POINT_COUNT;
    indices[2] = (indices[1]+1)%POINT_COUNT;
    indices[3] = (indices[2]+1)%POINT_COUNT;

    getCatmullRomPoint(t, p[indices[0]], p[indices[1]], p[indices[2]], p[indices[3]], pos, deriv);
}

int loadTexture(std::string s) {

    unsigned int t,tw,th;
    unsigned char *texData;
    unsigned int texID;
    ilInit();
    ilEnable(IL_ORIGIN_SET);
    ilOriginFunc(IL_ORIGIN_LOWER_LEFT);
    ilGenImages(1,&t);
    ilBindImage(t);
    ilLoadImage((ILstring)s.c_str());
    tw = ilGetInteger(IL_IMAGE_WIDTH);
    th = ilGetInteger(IL_IMAGE_HEIGHT);
    ilConvertImage(IL_RGBA, IL_UNSIGNED_BYTE);
    texData = ilGetData();
    glGenTextures(1,&texID);

    glBindTexture(GL_TEXTURE_2D,texID);
    glTexParameteri(GL_TEXTURE_2D,	GL_TEXTURE_WRAP_S,		GL_REPEAT);
    glTexParameteri(GL_TEXTURE_2D,	GL_TEXTURE_WRAP_T,		GL_REPEAT);

    glTexParameteri(GL_TEXTURE_2D,	GL_TEXTURE_MAG_FILTER,   	GL_LINEAR_MIPMAP_LINEAR);
    glTexParameteri(GL_TEXTURE_2D,	GL_TEXTURE_MIN_FILTER, GL_LINEAR_MIPMAP_LINEAR);

    glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA, tw, th, 0, GL_RGBA, GL_UNSIGNED_BYTE, texData);
    glGenerateMipmap(GL_TEXTURE_2D);

    glBindTexture(GL_TEXTURE_2D, 0);

    return texID;

}

void drawOrbitas(vector<float> controlPoints){

    float pos[3];
    float deriv[3];

    vector< vector<float> > aux;

    for(int i=0; i<controlPoints.size();i+=3){

        vector<float> ponto;
        ponto.push_back(controlPoints[i]);
        ponto.push_back(controlPoints[i+1]);
        ponto.push_back(controlPoints[i+2]);
        aux.push_back(ponto);
    }
    p.swap(aux);

    float white[4] = { 1.0f, 1.0f, 1.0f, 1.0f };

    if(mostraOrbita) {
        glBegin(GL_LINE_LOOP);

        for (float gt = 0; gt < 1; gt += 0.001) {

            getGlobalCatmullRomPoint(gt, pos, deriv,(controlPoints.size()/3));
            glMaterialfv(GL_FRONT,GL_AMBIENT,white);
            glNormal3f(-pos[0],-pos[1],-pos[2]);
            glVertex3f(pos[0],pos[1],pos[2]);
        }
        glEnd();
    }
 }

void drawFiguresText(vector< vector<float> > v, vector<float> color, vector<string> texturas, vector<Material> materials, vector<string> models) {

    int b;
    int x;
    bool flag1;
    bool flag2;
    int idText;


    for(int nmodelos = 0; nmodelos<v.size();nmodelos++) {

        flag1=false;
        flag2=false;

        for (b = 0; b < primitiveBuffers.size(); b++) {
            if (!strcmp(primitiveBuffers[b].model.c_str(), models[nmodelos].c_str())) {
                flag1 = true;
                break;
            }
        }

        if (flag1) {

            glMaterialfv(GL_FRONT, GL_AMBIENT, materials[nmodelos].ambient);
            glMaterialfv(GL_FRONT, GL_DIFFUSE, materials[nmodelos].diffuse);
            glMaterialfv(GL_FRONT, GL_EMISSION, materials[nmodelos].emissive);
            glMaterialfv(GL_FRONT, GL_SPECULAR, materials[nmodelos].specular);


            for (x = 0; x < loadedTextures.size(); x++) {
                if (!strcmp(loadedTextures[x].texture.c_str(), texturas[nmodelos].c_str())) {
                    flag2 = true;
                    break;
                }
            }

            if(flag2) {idText=loadedTextures[x].id;}

            else {
                idText = loadTexture(texturas[nmodelos]);
                loadedTexture texturaAtual;
                texturaAtual.id=idText;
                texturaAtual.texture=texturas[nmodelos];
                loadedTextures.push_back(texturaAtual);
            }

            glBindBuffer(GL_ARRAY_BUFFER, primitiveBuffers[b].buffers[0]);
            glVertexPointer(3, GL_FLOAT, 0, 0);

            glBindBuffer(GL_ARRAY_BUFFER, primitiveBuffers[b].buffers[1]);
            glNormalPointer(GL_FLOAT, 0, 0);

            glBindTexture(GL_TEXTURE_2D, idText);
            glBindBuffer(GL_ARRAY_BUFFER, primitiveBuffers[b].buffers[2]);
            glTexCoordPointer(2, GL_FLOAT, 0, 0);

            glDrawArrays(GL_TRIANGLES, 0, v[nmodelos][0]);
            glBindTexture(GL_TEXTURE_2D, 0);

        }

        else {

            glMaterialfv(GL_FRONT, GL_AMBIENT, materials[nmodelos].ambient);
            glMaterialfv(GL_FRONT, GL_DIFFUSE, materials[nmodelos].diffuse);
            glMaterialfv(GL_FRONT, GL_EMISSION, materials[nmodelos].emissive);
            glMaterialfv(GL_FRONT, GL_SPECULAR, materials[nmodelos].specular);

            GLuint vertices, normais, textCoord;

            float *p, *n, *t;

            int npontos = v[nmodelos][0] * 3;
            int nnormais = v[nmodelos][0] * 3;
            int ntexturas = v[nmodelos][0] * 2;


            p = (float *) malloc(sizeof(float) * npontos);
            n = (float *) malloc(sizeof(float) * nnormais);
            t = (float *) malloc(sizeof(float) * ntexturas);

            int vertex = 0;
            int i = 1;

            while (i < npontos) {
                p[vertex * 3 + 0] = v[nmodelos][i];
                p[vertex * 3 + 1] = v[nmodelos][i + 1];
                p[vertex * 3 + 2] = v[nmodelos][i + 2];
                i += 3;
                vertex++;
            }

            vertex = 0;
            while (i < npontos * 2) {
                n[vertex * 3 + 0] = v[nmodelos][i];
                n[vertex * 3 + 1] = v[nmodelos][i + 1];
                n[vertex * 3 + 2] = v[nmodelos][i + 2];
                i += 3;
                vertex++;
            }

            vertex = 0;
            while (i < (npontos * 2) + ntexturas) {
                t[vertex * 2 + 0] = v[nmodelos][i];
                t[vertex * 2 + 1] = v[nmodelos][i + 1];
                i += 2;
                vertex++;
            }

            GLuint vertexcount = vertex;

            glGenBuffers(1, &vertices);
            glBindBuffer(GL_ARRAY_BUFFER, vertices);
            glBufferData(GL_ARRAY_BUFFER, sizeof(float) * vertexcount * 3, p, GL_STATIC_DRAW);
            glGenBuffers(1, &normais);
            glBindBuffer(GL_ARRAY_BUFFER, normais);
            glBufferData(GL_ARRAY_BUFFER, sizeof(float) * vertexcount * 3, n, GL_STATIC_DRAW);
            glGenBuffers(1, &textCoord);
            glBindBuffer(GL_ARRAY_BUFFER, textCoord);
            glBufferData(GL_ARRAY_BUFFER, sizeof(float) * vertexcount * 2, t, GL_STATIC_DRAW);

            int idText = loadTexture(texturas[nmodelos]);

            glBindBuffer(GL_ARRAY_BUFFER, vertices);
            glVertexPointer(3, GL_FLOAT, 0, 0);

            glBindBuffer(GL_ARRAY_BUFFER, normais);
            glNormalPointer(GL_FLOAT, 0, 0);

            glBindTexture(GL_TEXTURE_2D, idText);
            glBindBuffer(GL_ARRAY_BUFFER, textCoord);
            glTexCoordPointer(2, GL_FLOAT, 0, 0);

            glDrawArrays(GL_TRIANGLES, 0, vertexcount);
            glBindTexture(GL_TEXTURE_2D, 0);

            primitiveBuffer atual;
            loadedTexture texturaAtual;

            texturaAtual.id=idText;
            texturaAtual.texture=texturas[nmodelos];
            loadedTextures.push_back(texturaAtual);

            atual.model=models[nmodelos];
            atual.buffers[0]=vertices;
            atual.buffers[1]=normais;
            atual.buffers[2]=textCoord;

            primitiveBuffers.push_back(atual);

            free(p);
            free(n);
            free(t);

        }
    }

}

void drawFiguresNormal(vector< vector<float> > v, vector<float> color, vector<Material> materials, vector<string> models) {
    int b;
    bool flag =false;

    for(int nmodelos = 0; nmodelos<v.size();nmodelos++) {
        flag=false;

        for( b =0; b<primitiveBuffers.size();b++) {
            if(!strcmp(primitiveBuffers[b].model.c_str(),models[nmodelos].c_str())) {
                flag = true;
                break;
            }

        }

        if (flag) {

            glMaterialfv(GL_FRONT, GL_AMBIENT, materials[nmodelos].ambient);
            glMaterialfv(GL_FRONT, GL_DIFFUSE, materials[nmodelos].diffuse);
            glMaterialfv(GL_FRONT, GL_EMISSION, materials[nmodelos].emissive);
            glMaterialfv(GL_FRONT, GL_SPECULAR, materials[nmodelos].specular);

            glBindBuffer(GL_ARRAY_BUFFER, primitiveBuffers[b].buffers[0]);
            glVertexPointer(3, GL_FLOAT, 0, 0);

            glBindBuffer(GL_ARRAY_BUFFER, primitiveBuffers[b].buffers[1]);
            glNormalPointer(GL_FLOAT, 0, 0);

            glDrawArrays(GL_TRIANGLES, 0, v[nmodelos][0]);

        }

        else {
            glMaterialfv(GL_FRONT, GL_AMBIENT, materials[nmodelos].ambient);
            glMaterialfv(GL_FRONT, GL_DIFFUSE, materials[nmodelos].diffuse);
            glMaterialfv(GL_FRONT, GL_EMISSION, materials[nmodelos].emissive);
            glMaterialfv(GL_FRONT, GL_SPECULAR, materials[nmodelos].specular);


            GLuint buffer, normals, textCoord;
            GLuint vertexCount;


            int vertex = 0;
            int i = 1;

            int npontos = v[nmodelos][0] * 3;
            int nnormais = v[nmodelos][0] * 3;
            int ntexturas = v[nmodelos][0] * 2;

            float *p, *n, *t;

            p = (float *) malloc(sizeof(float) * npontos);
            n = (float *) malloc(sizeof(float) * nnormais);
            t = (float *) malloc(sizeof(float) * ntexturas);


            while (i < npontos) {
                p[vertex * 3 + 0] = v[nmodelos][i];
                p[vertex * 3 + 1] = v[nmodelos][i + 1];
                p[vertex * 3 + 2] = v[nmodelos][i + 2];
                i += 3;
                vertex++;

            }

            vertex = 0;
            while (i < npontos * 2) {
                n[vertex * 3 + 0] = v[nmodelos][i];
                n[vertex * 3 + 1] = v[nmodelos][i + 1];
                n[vertex * 3 + 2] = v[nmodelos][i + 2];
                i += 3;
                vertex++;
            }


            vertex = 0;
            while (i < (npontos * 2) + ntexturas) {
                t[vertex * 2 + 0] = v[nmodelos][i];
                t[vertex * 2 + 1] = v[nmodelos][i + 1];
                i += 2;
                vertex++;
            }

            vertexCount = vertex;

            glGenBuffers(1, &buffer);
            glBindBuffer(GL_ARRAY_BUFFER, buffer);
            glBufferData(GL_ARRAY_BUFFER, sizeof(float) * vertexCount * 3, p, GL_STATIC_DRAW);

            glGenBuffers(1, &normals);
            glBindBuffer(GL_ARRAY_BUFFER, normals);
            glBufferData(GL_ARRAY_BUFFER, sizeof(float) * vertexCount * 3, n, GL_STATIC_DRAW);

            glGenBuffers(1, &textCoord);
            glBindBuffer(GL_ARRAY_BUFFER, textCoord);
            glBufferData(GL_ARRAY_BUFFER, sizeof(float) * vertexCount * 2, t, GL_STATIC_DRAW);

            glBindBuffer(GL_ARRAY_BUFFER, buffer);
            glVertexPointer(3, GL_FLOAT, 0, 0);

            glBindBuffer(GL_ARRAY_BUFFER, normals);
            glNormalPointer(GL_FLOAT, 0, 0);

            glBindBuffer(GL_ARRAY_BUFFER, textCoord);
            glTexCoordPointer(2, GL_FLOAT, 0, 0);

            glDrawArrays(GL_TRIANGLES, 0, vertexCount);

            primitiveBuffer atual;

            atual.model=models[nmodelos];
            atual.buffers[0]=buffer;
            atual.buffers[1]=normals;
            atual.buffers[2]=textCoord;

            primitiveBuffers.push_back(atual);

            free(p);
            free(n);
            free(t);

        }

    }

}

void renderCometa(vector< vector<float> > v, vector<float> color, float time,vector<Material> materials, vector<string> texturas, int npontos, vector<string> models){
    float deriv[3];
    float z[3];
    float pos[3];
    static float elapsed_time=0;

    elapsed_time = glutGet(GLUT_ELAPSED_TIME);
    getGlobalCatmullRomPoint(1/(time*1000)*elapsed_time, pos, deriv,npontos);
    // z é o vetor perpendicular aos vetores deriv e up
    cross(deriv, y, z);
    normalize(z);


    cross(z, deriv, y);
    normalize(y);

    normalize(deriv);

    float m[16];

    buildRotMatrix(deriv, y, z, m);
    glMultMatrixf(m);
    glRotatef(-90,1.0,0.0,0.0);
    if(texturas.size()!=0){
    drawFiguresText(v,color,texturas, materials,models);}
    else drawFiguresNormal(v,color, materials,models);
}

void drawGroup(Group grupo) {
    float pos[3];
    float deriv[3];
    float elapsed_time;

    vector< vector<float> > v = parserFicheiroModels(grupo.models);

        glPushMatrix();

    if (mostraVisao) {glRotatef(grupo.orbit.angle,0,0,1);}

            glTranslatef(grupo.translate.x,grupo.translate.y,grupo.translate.z);

            if(grupo.controlPoints.size()!=0) {

                elapsed_time = glutGet(GLUT_ELAPSED_TIME);

                drawOrbitas(grupo.controlPoints);


                if(grupo.translate.time!=0){

                    getGlobalCatmullRomPoint(1/(grupo.translate.time*1000)*elapsed_time, pos, deriv,grupo.controlPoints.size()/3);

                    glTranslatef(pos[0], pos[1], pos[2]);
                }

                else glTranslatef(grupo.translate.x,grupo.translate.y,grupo.translate.z);

            }

            glScalef(grupo.scale.x, grupo.scale.y, grupo.scale.z);

            for(int i=0 ; i < grupo.groups.size(); i++){
                drawGroup(grupo.groups[i]);

            }


            if(grupo.rotate.time > 0){
                float time = grupo.rotate.time;

                elapsed_time = glutGet(GLUT_ELAPSED_TIME);
                glRotatef(grupo.rotate.angle,0,0,1);
                glRotatef((360/(time*1000))*elapsed_time,grupo.rotate.x,grupo.rotate.y,grupo.rotate.z);
             }

            if(grupo.rotate.time == 0)  glRotatef(grupo.rotate.angle,grupo.rotate.x,grupo.rotate.y,grupo.rotate.z);


            if(grupo.rotate.time < 0) {
                renderCometa(v,grupo.color,grupo.translate.time, grupo.material,grupo.textures,grupo.controlPoints.size()/3,grupo.models);
            }

            else {
               if(grupo.textures.size()!=0) {
                   drawFiguresText(v, grupo.color, grupo.textures,grupo.material,grupo.models);
                   }
                else {drawFiguresNormal(v, grupo.color,grupo.material,grupo.models);}

            }

    glPopMatrix();
}

void drawAllGroup(){

    for(int i=0 ; i < grupos.size(); i++){
        drawGroup(grupos[i]);
    }
}

void prepareCube() {
    int r=0;
    for (int i = 1; i < imageWidth - 2; i++) {
        for (int j = 1; j < imageWidth - 1; j++) {

            computeNormal(i + 1, j);

            texCoord.push_back((i+1)*0.01);
            r++;
            texCoord.push_back(j*0.01);
            r++;


            position.push_back(i - imageWidth*0.5f + 1);
            position.push_back(0);
            position.push_back(j - imageWidth*0.5f);

            computeNormal(i, j);

            texCoord.push_back(i*0.01);
            r++;
            texCoord.push_back(j*0.01);
            r++;

            position.push_back(i - imageWidth*0.5f);
            position.push_back(0);
            position.push_back(j - imageWidth*0.5f);
        }
    }
    glGenBuffers(3, buffers);

    glBindBuffer(GL_ARRAY_BUFFER, buffers[0]);
    glBufferData(GL_ARRAY_BUFFER, position.size() * sizeof(float), &(position[0]), GL_STATIC_DRAW);

    glBindBuffer(GL_ARRAY_BUFFER, buffers[1]);
    glBufferData(GL_ARRAY_BUFFER, normal.size() * sizeof(float), &(normal[0]), GL_STATIC_DRAW);

    glBindBuffer(GL_ARRAY_BUFFER, buffers[2]);
    glBufferData(GL_ARRAY_BUFFER, texCoord.size() * sizeof(float), &(texCoord[0]), GL_STATIC_DRAW);


}

void rendercube(){
    glBindTexture(GL_TEXTURE_2D, texture);
    glBindBuffer(GL_ARRAY_BUFFER, buffers[0]);
    glVertexPointer(3, GL_FLOAT, 0, 0);

    glBindBuffer(GL_ARRAY_BUFFER, buffers[1]);
    glNormalPointer(GL_FLOAT, 0, 0);

    glBindBuffer(GL_ARRAY_BUFFER, buffers[2]);
    glTexCoordPointer(2, GL_FLOAT, 0, 0);

    for (int i = 1; i < imageWidth - 2; i++) {
        glDrawArrays(GL_TRIANGLE_STRIP, (imageWidth - 2) * 2 * i, (imageWidth - 2) * 2);
    }
    glBindTexture(GL_TEXTURE_2D, 0);


}

void drawCube(){
    float white[4] = { 1.0f, 1.0f, 1.0f, 1.0f };
    glMaterialfv(GL_FRONT, GL_AMBIENT_AND_DIFFUSE, white);

    glPushMatrix();

        glPushMatrix();
            glTranslatef(0.0,-((imageWidth/2)-2),0.0);
            rendercube();
        glPopMatrix();

        glPushMatrix();
            glTranslatef(0.0,((imageWidth/2)-2),0.0);
            glRotatef(180.0,1.0,0.0,0.0);
            rendercube();
        glPopMatrix();

        glPushMatrix();
            glTranslatef(0.0,0.0,-((imageWidth/2)-2));
            glRotatef(180.0-90.0,1.0,0.0,0.0);
            rendercube();
        glPopMatrix();

        glPushMatrix();
            glTranslatef(0.0,0.0,((imageWidth/2)-2));
            glRotatef(-90.0,1.0,0.0,0.0);
            rendercube();
        glPopMatrix();

        glPushMatrix();
            glTranslatef(((imageWidth/2)-2),0.0,0.0);
            glRotatef(90.0,0.0,0.0,1.0);
            rendercube();
        glPopMatrix();

        glPushMatrix();
            glTranslatef(-((imageWidth/2)-2),0.0,0.0);
            glRotatef(180+90.0,0.0,0.0,1.0);
            rendercube();
        glPopMatrix();
    glPopMatrix();
}

void turnuplight(vector<Light> lights){

    for(int i=0; i<lights.size();i++){

        if(!strcmp(lights[i].type.c_str(),"POINT")){
            lights[i].position[3]=1;
        }
        else lights[i].position[3]=0;

        glLightfv(i + GL_LIGHT0, GL_POSITION, lights[i].position);
        glLightfv(i + GL_LIGHT0, GL_AMBIENT, lights[i].ambient);
        glLightfv(i + GL_LIGHT0, GL_DIFFUSE, lights[i].diffuse);
        glLightfv(i + GL_LIGHT0, GL_SPECULAR, lights[i].specular);

        if(!strcmp(lights[i].type.c_str(),"SPOT")) {
            glLightfv(i + GL_LIGHT0, GL_SPOT_DIRECTION, lights[i].spot_direction);
            glLightf(i + GL_LIGHT0, GL_SPOT_CUTOFF, lights[i].spot_cutoff);
        }
    }
}

void renderScene(void) {

    float fps;
    int time;
    char s[64];

    glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

    glLoadIdentity();
    gluLookAt(camX, camY, camZ,
              0,0,0,
              0.0f,1.0f,0.0f);

    turnuplight(lights);

    if(mostraTextura) {drawCube();}

    frame++;
    time = glutGet(GLUT_ELAPSED_TIME);
    if (time - timebase > 1000) {
        fps = frame*1000.0 / (time - timebase);
        timebase = time;
        frame = 0;
        sprintf(s, "FPS: %2.6f", fps);
        glutSetWindowTitle(s);
    }

    drawAllGroup();

    t+=0.001;

    glutSwapBuffers();
}

void loadTextureCubo() {

    unsigned int t, tw, th;
    unsigned char *texData;
    ilGenImages(1, &t);
    ilBindImage(t);
    ilLoadImage((ILstring)"textures/space.jpg");
    tw = ilGetInteger(IL_IMAGE_WIDTH);
    th = ilGetInteger(IL_IMAGE_HEIGHT);
    ilConvertImage(IL_RGBA, IL_UNSIGNED_BYTE);
    texData = ilGetData();

    glGenTextures(1, &texture);

    glBindTexture(GL_TEXTURE_2D, texture);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT);

    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR_MIPMAP_LINEAR);

    glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA, tw, th, 0, GL_RGBA, GL_UNSIGNED_BYTE, texData);
    glGenerateMipmap(GL_TEXTURE_2D);
}

void init() {

    unsigned int ima[1];

    ilInit();
    ilGenImages(1, ima);
    ilBindImage(ima[0]);
    ilLoadImage((ILstring)"textures/terreno3.jpg");
    ilConvertImage(IL_LUMINANCE, IL_UNSIGNED_BYTE);

    imageWidth = ilGetInteger(IL_IMAGE_HEIGHT);
    imageData = ilGetData();
    prepareCube();
    loadTextureCubo();

    glEnable(GL_TEXTURE_2D);
    glEnable(GL_DEPTH_TEST);
    glEnable(GL_LIGHTING);
    glEnable(GL_NORMALIZE);
    glEnableClientState(GL_VERTEX_ARRAY);
    glEnableClientState(GL_NORMAL_ARRAY);
    glEnableClientState(GL_TEXTURE_COORD_ARRAY);

    glEnable(GL_TEXTURE_2D);

}

void changeSize(int w, int h) {

    if(h == 0)
        h = 1;


    float ratio = w * 1.0 / h;


    glMatrixMode(GL_PROJECTION);
    glLoadIdentity();

    glViewport(0, 0, w, h);

    gluPerspective(45.0f ,ratio, 1.0f ,1000.0f);

    glMatrixMode(GL_MODELVIEW);
}

void processSpecialKeys(int key, int xx, int yy) {

    switch (key) {

        case GLUT_KEY_RIGHT:
            alfa -= 0.1; break;

        case GLUT_KEY_LEFT:
            alfa += 0.1; break;

        case GLUT_KEY_UP:
            beta += 0.1f;
            if (beta > 1.5f)
                beta = 1.5f;
            break;

        case GLUT_KEY_DOWN:
            beta -= 0.1f;
            if (beta < -1.5f)
                beta = -1.5f;
            break;

        case GLUT_KEY_PAGE_DOWN: radius -= 20.0f;
            if (radius < 1.0f)
                radius = 1.0f;
            break;

        case GLUT_KEY_PAGE_UP: radius += 20.0f; break;
    }
    spherical2Cartesian();
    glutPostRedisplay();

}

void processMenuEvents(int option) {
    switch (option) {
        case 1:
            glPolygonMode(GL_FRONT_AND_BACK, GL_LINE);
            break;
        case 2:
            glPolygonMode(GL_FRONT_AND_BACK, GL_FILL);
            break;
        case 3:
            if(mostraOrbita) mostraOrbita=0;
            else mostraOrbita=1;
            break;
        case 4:
            if(mostraTextura) mostraTextura=0;
            else mostraTextura=1;
            break;
        case 5:
            if(mostraVisao) mostraVisao=0;
            break;
        case 6:
            if(!mostraVisao) mostraVisao=1;
            break;
        default:
            break;
    }

    glutPostRedisplay();
}

void menus() {

    int menu;


    menu = glutCreateMenu(processMenuEvents);

    glutAddMenuEntry("SEE WIRED", 1);
    glutAddMenuEntry("SEE SOLID", 2);
    glutAddMenuEntry("ORBITS", 3);
    glutAddMenuEntry("TEXTURES", 4);
    glutAddMenuEntry("NORMAL VISION", 5);
    glutAddMenuEntry("REALISTIC VISION", 6);

    glutAttachMenu(GLUT_RIGHT_BUTTON);
}

int main(int argc, char **argv) {

    glutInit(&argc, argv);
    glutInitDisplayMode(GLUT_DEPTH|GLUT_DOUBLE|GLUT_RGBA);
    glutInitWindowPosition(100,100);
    glutInitWindowSize(800,800);
    glutCreateWindow("Fase-II");
    glClearColor(1, 1, 1, 1);

    lights = parseLigth(argv[1]);
    grupos = parseAll(argv[1]);


    //glPolygonMode( GL_FRONT_AND_BACK, GL_LINE);
    glutDisplayFunc(renderScene);
    glutIdleFunc(renderScene);
    glutReshapeFunc(changeSize);


    glutSpecialFunc(processSpecialKeys);
    menus();



        glEnable(GL_DEPTH_TEST);
        glEnable(GL_CULL_FACE);


    spherical2Cartesian();

    #ifndef __APPLE__   
    glewInit();
    #endif

    if(mostraTextura) init();
    glutMainLoop();


    return 1;
}
