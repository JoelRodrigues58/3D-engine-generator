#include <iostream>
#include <fstream>
#include <string>
#include <stdlib.h>
#include <sstream>
#include <vector>
#include "../tinyxml/tinyxml.h"

using namespace std;

typedef struct Translate{
    float x;
    float y;
    float z;
    float time;
}Translate;

typedef struct Rotate{
    float angle;
    float x;
    float y;
    float z;
    float time;
}Rotate;

typedef struct Orbit{
    float angle;
}Orbit;

typedef struct Scale{
    float x;
    float y;
    float z;
}Scale;


typedef struct Material{
    float ambient[4];
    float emissive[4];
    float specular[4];
    float diffuse[4];

}Material;


typedef struct Light{
    string type;
    float ambient[4];
    float specular[4];
    float diffuse[4];
    float position[4];
    float spot_direction[3];
    float spot_cutoff;

}Light;


typedef struct group{
    Translate translate;
    Rotate rotate;
    Scale scale;
    Orbit orbit;
    vector<float> controlPoints;
    vector<string> textures;
    vector<float> color;
    vector<Material> material;
    vector<string> models;
    vector<group> groups;
}Group;


Group getGroups(TiXmlElement *pParm, char const *file_name);

vector<Group> parseAll(char const *file_name);

vector< vector<float> >  parserFicheiroModels (vector<string> models);

vector<Light> parseLigth(char const *file_name);