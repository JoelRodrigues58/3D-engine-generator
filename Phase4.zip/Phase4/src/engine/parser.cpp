#ifdef __APPLE__
#include <GLUT/glut.h>
#else
#include <GL/glut.h>
#endif

#define _USE_MATH_DEFINES
#include <math.h>
#include "parser.h"

#include <iostream>


Group getGroups(TiXmlElement *pParm, char const *file_name){
    const char* translateX; const char* translateY; const char* translateZ; const char * translateT;
    const char* rotateA; const char* rotateX; const char* rotateY; const char* rotateZ; const char* rotateT;
    const char* scaleX; const char* scaleY; const char* scaleZ;
    const char* r; const char* g; const char* b;
    const char* x; const char* y; const char* z;
    const char* ambR; const char* ambG; const char* ambB;
    const char* difR; const char* difG; const char* difB;
    const char* speR; const char* speG; const char* speB;
    const char* emiR; const char* emiG; const char* emiB;
    const char* angle;
    string name;
    string textura;

    TiXmlElement *pFilho, *pFilhosGrupo, *pPoints;

    Group grupo;
    if (pParm){
        Translate translate;
        Rotate rotate;
        Scale scale;
        Orbit orbit;
        Material material;
        vector<Material> materials;
        vector<float> color;
        vector<string> modelos;
        vector<string> texturas;
        vector<float> controlP;

        material.ambient[0]=0.2; material.ambient[1]=0.2; material.ambient[2]=0.2; material.ambient[3]=0;
        material.diffuse[0]=0.8; material.diffuse[1]=0.8; material.diffuse[2]=0.8; material.diffuse[3]=0;
        material.emissive[0]=0; material.emissive[1]=0; material.emissive[2]=0; material.emissive[3]=0;
        material.specular[0]=0; material.specular[1]=0; material.specular[2]=0; material.specular[3]=0;

        translate.x = 0;
        translate.y = 0;
        translate.z = 0;
        translate.time=0;
        rotate.angle = 0;
        rotate.x = 0;
        rotate.y = 0;
        rotate.z = 0;
        rotate.time=0;
        scale.x = 1;
        scale.y = 1;
        scale.z = 1;
        r=0;
        g=0;
        b=0;
        orbit.angle=0;

        if (pParm->FirstChildElement("translate")) {
            TiXmlAttribute *pAttrib = pParm->FirstChildElement("translate")->FirstAttribute();
            pPoints = pParm->FirstChildElement("translate")->FirstChildElement();
            while (pAttrib) {
                if (!strcmp(pAttrib->Name(), "X")) {
                    translateX = pAttrib->Value();
                    translate.x = atof(translateX);

                } else if (!strcmp(pAttrib->Name(), "Y")) {
                    translateY = pAttrib->Value();
                    translate.y = atof(translateY);

                } else if (!strcmp(pAttrib->Name(), "Z")) {
                    translateZ = pAttrib->Value();
                    translate.z = atof(translateZ);
                }

                else if (!strcmp(pAttrib->Name(), "T")) {
                    translateT = pAttrib->Value();
                    translate.time = atof(translateT);
                }
                pAttrib = pAttrib->Next();

            }

            while (pPoints) {

                    TiXmlAttribute *pPointA = pPoints->FirstAttribute();

                    while (pPointA) {
                        if (!strcmp(pPointA->Name(), "X")) {
                            x = pPointA->Value();
                            controlP.push_back(atof(x));

                        } else if (!strcmp(pPointA->Name(), "Y")) {
                            y = pPointA->Value();
                            controlP.push_back(atof(y));

                        } else if (!strcmp(pPointA->Name(), "Z")) {
                            z = pPointA->Value();
                            controlP.push_back(atof(z));
                        }

                        pPointA = pPointA->Next();
                    }

                    pPoints = pPoints->NextSiblingElement("point");

                }

            }


        if (pParm->FirstChildElement("rotate")) {
            TiXmlAttribute *pAttrib = pParm->FirstChildElement("rotate")->FirstAttribute();
            while (pAttrib) {
                if (!strcmp(pAttrib->Name(), "angle")) {
                    rotateA = pAttrib->Value();
                    rotate.angle = atof(rotateA);

                } else if (!strcmp(pAttrib->Name(), "axisX")) {
                    rotateX = pAttrib->Value();
                    rotate.x = atof(rotateX);

                } else if (!strcmp(pAttrib->Name(), "axisY")) {
                    rotateY = pAttrib->Value();
                    rotate.y = atof(rotateY);
                } else if (!strcmp(pAttrib->Name(), "axisZ")) {
                    rotateZ = pAttrib->Value();
                    rotate.z = atof(rotateZ);

                } else if (!strcmp(pAttrib->Name(), "T")) {
                rotateT = pAttrib->Value();
                rotate.time = atof(rotateT);
            }

                pAttrib = pAttrib->Next();

            }

        }


        if (pParm->FirstChildElement("scale")) {
            TiXmlAttribute *pAttrib = pParm->FirstChildElement("scale")->FirstAttribute();
            while (pAttrib) {
                if (!strcmp(pAttrib->Name(), "X")) {
                    scaleX = pAttrib->Value();
                    scale.x = atof(scaleX);

                } else if (!strcmp(pAttrib->Name(), "Y")) {
                    scaleY = pAttrib->Value();
                    scale.y = atof(scaleY);
                } else if (!strcmp(pAttrib->Name(), "Z")) {
                    scaleZ = pAttrib->Value();
                    scale.z = atof(scaleZ);
                }

                pAttrib = pAttrib->Next();

            }
        }


        if (pParm->FirstChildElement("orbit")) {
            TiXmlAttribute *pAttrib = pParm->FirstChildElement("orbit")->FirstAttribute();
            while (pAttrib) {
                if (!strcmp(pAttrib->Name(), "Angle")) {
                    angle = pAttrib->Value();
                    orbit.angle = atof(angle);
                }

                pAttrib = pAttrib->Next();

            }
        }

        if (pParm->FirstChildElement("color")) {
            TiXmlAttribute *pAttrib = pParm->FirstChildElement("color")->FirstAttribute();
            while (pAttrib) {
                if (!strcmp(pAttrib->Name(), "R")) {
                    r = pAttrib->Value();
                    color.push_back(atof(r));

                }
                else if (!strcmp(pAttrib->Name(), "G")) {
                    g = pAttrib->Value();
                    color.push_back(atof(g));
                }
                else if (!strcmp(pAttrib->Name(), "B")) {
                    b = pAttrib->Value();
                    color.push_back(atof(b));
                }

                pAttrib = pAttrib->Next();
            }
        }

        if (pParm->FirstChildElement("models")) {

            pFilho = pParm->FirstChildElement("models");

            while (pFilho) {

                TiXmlAttribute *pAttrib = pFilho->FirstChildElement("model")->FirstAttribute();

                    while (pAttrib) {
                        if (!strcmp(pAttrib->Name(), "file")) {
                            name = pAttrib->Value();
                            modelos.push_back(name);
                        }
                        else if (!strcmp(pAttrib->Name(), "texture")) {
                            textura = pAttrib->Value();
                            texturas.push_back(textura);

                        }
                        else if (!strcmp(pAttrib->Name(), "ambR")) {
                            ambR = pAttrib->Value();
                            material.ambient[0]=atof(ambR);
                            material.ambient[3]=1;
                        }
                        else if (!strcmp(pAttrib->Name(), "ambG")) {
                            ambG = pAttrib->Value();
                            material.ambient[1]=atof(ambG);
                            material.ambient[3]=1;
                        }
                        else if (!strcmp(pAttrib->Name(), "ambB")) {
                            ambB = pAttrib->Value();
                            material.ambient[2]=atof(ambB);
                            material.ambient[3]=1;
                        }

                        else if (!strcmp(pAttrib->Name(), "difR")) {
                            difR = pAttrib->Value();
                            material.diffuse[0]=atof(difR);
                            material.diffuse[3]=1;
                        }
                        else if (!strcmp(pAttrib->Name(), "difG")) {
                            difG = pAttrib->Value();
                            material.diffuse[1]=atof(difG);
                            material.diffuse[3]=1;
                        }
                        else if (!strcmp(pAttrib->Name(), "difB")) {
                            difB = pAttrib->Value();
                            material.diffuse[2]=atof(difB);
                            material.diffuse[3]=1;
                        }

                        else if (!strcmp(pAttrib->Name(), "emiR")) {
                            emiR = pAttrib->Value();
                            material.emissive[0]=atof(emiR);
                            material.emissive[3]=1;
                        }
                        else if (!strcmp(pAttrib->Name(), "emiG")) {
                            emiG = pAttrib->Value();
                            material.emissive[1]=atof(emiG);
                            material.emissive[3]=1;
                        }
                        else if (!strcmp(pAttrib->Name(), "emiB")) {
                            emiB = pAttrib->Value();
                            material.emissive[2]=atof(emiB);
                            material.emissive[3]=1;
                        }

                        else if (!strcmp(pAttrib->Name(), "speR")) {
                            speR = pAttrib->Value();
                            material.specular[0]=atof(speR);
                            material.specular[3]=1;
                        }
                        else if (!strcmp(pAttrib->Name(), "speG")) {
                            speG = pAttrib->Value();
                            material.specular[1]=atof(speG);
                            material.specular[3]=1;
                        }
                        else if (!strcmp(pAttrib->Name(), "speB")) {
                            speB = pAttrib->Value();
                            material.specular[2]=atof(speB);
                            material.specular[3]=1;
                        }

                        pAttrib = pAttrib->Next();
                    }

                        materials.push_back(material);

                        pFilho = pFilho->NextSiblingElement("model");

            }

        }

        pFilhosGrupo = pParm->FirstChildElement("group");

        while(pFilhosGrupo) {
            Group x = getGroups(pFilhosGrupo,file_name);

            grupo.groups.push_back(x);
            pFilhosGrupo= pFilhosGrupo->NextSiblingElement();
        }

        grupo.translate = translate;
        grupo.rotate = rotate;
        grupo.scale = scale;
        grupo.models = modelos;
        grupo.orbit = orbit;
        grupo.color = color;
        grupo.textures = texturas;
        grupo.material= materials;
        grupo.controlPoints=controlP;


    }
    return grupo;

}

vector<Light> parseLigth(char const *file_name) {
    vector<Light> lights;
    TiXmlElement *pFilho;
    TiXmlDocument doc(file_name);
    const char *type;const char *ambR;const char *ambG;const char *ambB;
    const char *difR;const char *difG;const char *difB;
    const char *speR;const char *speG;const char *speB;
    const char *coordx;const char *coordy;const char *coordz;
    const char *dirx;const char *diry;const char *dirz;
    const char *cutoff;
    Light light;
    int i=0;
    light.ambient[0] = 0;light.ambient[1] = 0;light.ambient[2] = 0;light.ambient[3] = 0;
    light.diffuse[0] = 1;light.diffuse[1] = 1;light.diffuse[2] = 1;light.diffuse[3] = 0;
    light.specular[0] = 1;light.specular[1] = 1;light.specular[2] = 1;light.specular[3] = 0;

    light.position[0] = 0;light.position[1] = 0;light.position[2] = 1;light.position[3] = 0;
    light.spot_direction[0] = 0;light.spot_direction[1] = 0;light.spot_direction[2] = -1;
    light.spot_cutoff = 180.0f;

    if(doc.LoadFile()) {
        TiXmlElement *pRoot, *pParm;
        pRoot = doc.FirstChildElement("scene");
        if (pRoot) {

            if (pRoot->FirstChildElement("lights")) {
                pParm = pRoot->FirstChildElement("lights");

    if (pParm) {

        if (pParm->FirstChildElement("light")) {

            pFilho = pParm->FirstChildElement("light");

            while (pFilho) {

                TiXmlAttribute *pAttrib = pFilho->FirstAttribute();

                while (pAttrib) {
                    if (!strcmp(pAttrib->Name(), "type")) {
                        type = pAttrib->Value();
                        light.type = type;
                    } else if (!strcmp(pAttrib->Name(), "ambR")) {
                        ambR = pAttrib->Value();
                        light.ambient[0] = atof(ambR);
                        light.ambient[3]=1;
                    } else if (!strcmp(pAttrib->Name(), "ambG")) {
                        ambG = pAttrib->Value();
                        light.ambient[1] = atof(ambG);
                        light.ambient[3]=1;
                    } else if (!strcmp(pAttrib->Name(), "ambB")) {
                        ambB = pAttrib->Value();
                        light.ambient[2] = atof(ambB);
                        light.ambient[3]=1;
                    } else if (!strcmp(pAttrib->Name(), "difR")) {
                        difR = pAttrib->Value();
                        light.diffuse[0] = atof(difR);
                        light.diffuse[3]=1;
                    } else if (!strcmp(pAttrib->Name(), "difG")) {
                        difG = pAttrib->Value();
                        light.diffuse[1] = atof(difG);
                        light.diffuse[3]=1;
                    } else if (!strcmp(pAttrib->Name(), "difB")) {
                        difB = pAttrib->Value();
                        light.diffuse[2] = atof(difB);
                        light.diffuse[3]=1;
                    } else if (!strcmp(pAttrib->Name(), "speR")) {
                        speR = pAttrib->Value();
                        light.specular[0] = atof(speR);
                        light.specular[3]=1;
                    } else if (!strcmp(pAttrib->Name(), "speG")) {
                        speG = pAttrib->Value();
                        light.specular[1] = atof(speG);
                        light.specular[3]=1;
                    } else if (!strcmp(pAttrib->Name(), "speB")) {
                        speB = pAttrib->Value();
                        light.specular[2] = atof(speB);
                        light.specular[3]=1;
                    } else if (!strcmp(pAttrib->Name(), "X")) {
                        coordx = pAttrib->Value();
                        light.position[0] = atof(coordx);
                    } else if (!strcmp(pAttrib->Name(), "Y")) {
                        coordy = pAttrib->Value();
                        light.position[1] = atof(coordy);
                    } else if (!strcmp(pAttrib->Name(), "Z")) {
                        coordz = pAttrib->Value();
                        light.position[2] = atof(coordz);
                    } else if (!strcmp(pAttrib->Name(), "dirX")) {
                        dirx = pAttrib->Value();
                        light.spot_direction[0] = atof(dirx);
                    } else if (!strcmp(pAttrib->Name(), "dirY")) {
                        diry = pAttrib->Value();
                        light.spot_direction[1] = atof(diry);
                    } else if (!strcmp(pAttrib->Name(), "dirZ")) {
                        dirz = pAttrib->Value();
                        light.spot_direction[2] = atof(dirz);
                    } else if (!strcmp(pAttrib->Name(), "cutoff")) {
                        cutoff = pAttrib->Value();
                        light.spot_cutoff = atof(cutoff);
                    }

                    pAttrib = pAttrib->Next();
                }
                lights.push_back(light);
                glEnable(i + GL_LIGHT0);
                i++;
                pFilho = pFilho->NextSiblingElement("light");

            }

        }
    }

            }
        }
    }
    else {
        printf("Impossível de ler o ficheiro!");
    }
    return lights;
}

vector<Group> parseAll(char const *file_name){
    vector<Group> grupos;
    TiXmlDocument doc(file_name);

    if(doc.LoadFile()) {
        TiXmlElement *pRoot, *pParm;
        pRoot = doc.FirstChildElement("scene");
        if (pRoot) {

            if (pRoot->FirstChildElement("group")) {
                pParm = pRoot->FirstChildElement("group");

                while (pParm) {
                    Group x = getGroups(pParm, file_name);
                    grupos.push_back(x);
                    pParm = pParm->NextSiblingElement("group");
                }
            }

        }
    }
    else {
        printf("Impossível de ler o ficheiro!");
    }

    return grupos;
}

vector< vector<float> > parserFicheiroModels (vector<string> models){
    ifstream myReadFile;
    vector< vector<float> > res;

    for(int j=0 ; j< models.size() ; j++) {
        vector<float> v;
        myReadFile.open(models[j].c_str());

        string output;
        float x, y, z;
        char *pEnd;
        int i = 0;
        int textura_z=1;
        float npontos;
        if (myReadFile.is_open()) {

            while (!myReadFile.eof()) {

                getline(myReadFile, output);

                const char *str = output.c_str();
                x = strtof(str, &pEnd);
                y = strtof(pEnd, &pEnd);
                z = strtof(pEnd, NULL);
                v.push_back(x);
                if(i==0) {npontos = x;}
                if (i != 0) {
                    v.push_back(y);
                    if(i<= npontos*2) {v.push_back(z);}
                    textura_z++;
                }
                i++;
            }
        }

        myReadFile.close();

        res.push_back(v);
    }

    return res;
}