#include <unistd.h> /* chamadas ao sistema: defs e decls essenciais */
#include <fcntl.h> /* O_RDONLY, O_WRONLY, O_CREAT, O_* */
#include <stdlib.h>
#include <stdio.h>
#include <string.h>

#include <iostream>
#include <fstream>
#include <string>
#include <stdlib.h>
#include <sstream>
#include <vector>

using namespace std;

int plane(float size, char* file_name);

int cone(float radius,float height, int slices,int stacks,char* file_name);

int sphere(float radius, int slices,int stacks,char* file_name);

int cintura_asteroides(float radius, int slices,int stacks, int n_asteroides, char* file_name);

void box(float x,float y,float z,int n_dimensions,char* file_name);

void torus(float ri, float re, int slices,int stacks,char* file_name);

float** multMatrixMatrix(int L1, int C1, float ** m1, int L2, int C2, float ** m2);

void vectorToMatrixX(vector<float> vec, int divisions, float ** res);

void vectorToMatrixY(vector<float> vec, int divisions, float ** res);

void vectorToMatrixZ(vector<float> vec, int divisions, float ** res);

void matrixTranspose(int L, int C, float ** m, float ** res);

void matrixInit(int L,int C, float** m);

void clearMatrix(int L, int C, float** m);

vector<float>  bezierMatrixFormula(vector<float> patch_pontos, float t1, float t2);

vector<float> getPontosIndices(int indice,vector< vector<int> > *patches , vector<float> *pontos );

void parserFicheiroPatch (const char* filename, vector< vector<int> > *patches , vector<float> *pontos );

void teapot (char*filenamePatch, int tessellation, char* filenameGenerator);