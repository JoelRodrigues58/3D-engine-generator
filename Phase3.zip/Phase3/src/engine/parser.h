#include <iostream>
#include <fstream>
#include <string>
#include <stdlib.h>
#include <sstream>
#include <vector>
#include "../tinyxml/tinyxml.h"

using namespace std;

typedef struct Translate{
    float x;
    float y;
    float z;
    float time;
}Translate;

typedef struct Rotate{
    float angle;
    float x;
    float y;
    float z;
    float time;
}Rotate;

typedef struct Orbit{
    float Rmenor;
    float Rmaior;
    float angle;
}Orbit;

typedef struct Scale{
    float x;
    float y;
    float z;
}Scale;

typedef struct group{
    Translate translate;
    Rotate rotate;
    Scale scale;
    Orbit orbit;
    vector<float> color;
    vector<string> models;
    vector<group> groups;
}Group;


Group getGroups(TiXmlElement *pParm, char const *file_name);

vector<Group> parseAll(char const *file_name);

vector<float> parserFicheiroModels (vector<string> models);
