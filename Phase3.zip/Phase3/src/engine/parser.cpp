#ifdef __APPLE__
#include <GLUT/glut.h>
#else
#include <GL/glut.h>
#endif

#define _USE_MATH_DEFINES
#include <math.h>
#include "parser.h"

#include <iostream>


Group getGroups(TiXmlElement *pParm, char const *file_name){
    const char* afelio;
    const char* perelio;
    const char* translateX;
    const char* translateY;
    const char* translateZ;
    const char * translateT;
    const char* rotateA;
    const char* rotateX;
    const char* rotateY;
    const char* rotateZ;
    const char* rotateT;
    const char* scaleX;
    const char* scaleY;
    const char* scaleZ;
    const char* r;
    const char* g;
    const char* b;
    const char* angle;
    string name;
    TiXmlElement *pFilho, *pModels, *pFilhosGrupo;
    Group grupo;
    if (pParm){
        Translate translate;
        Rotate rotate;
        Scale scale;
        Orbit orbit;
        vector<float> color;
        vector<string> modelos;
        translate.x = 0;
        translate.y = 0;
        translate.z = 0;
        translate.time=0;
        rotate.angle = 0;
        rotate.x = 0;
        rotate.y = 0;
        rotate.z = 0;
        rotate.time=0;
        scale.x = 1;
        scale.y = 1;
        scale.z = 1;
        r=0;
        g=0;
        b=0;
        orbit.Rmaior=0;
        orbit.Rmenor=0;
        orbit.angle=0;

        if (pParm->FirstChildElement("translate")) {
            TiXmlAttribute *pAttrib = pParm->FirstChildElement("translate")->FirstAttribute();
            while (pAttrib) {
                if (!strcmp(pAttrib->Name(), "X")) {
                    translateX = pAttrib->Value();
                    translate.x = atof(translateX);

                } else if (!strcmp(pAttrib->Name(), "Y")) {
                    translateY = pAttrib->Value();
                    translate.y = atof(translateY);

                } else if (!strcmp(pAttrib->Name(), "Z")) {
                    translateZ = pAttrib->Value();
                    translate.z = atof(translateZ);
                }

                else if (!strcmp(pAttrib->Name(), "T")) {
                    translateT = pAttrib->Value();
                    translate.time = atof(translateT);
                }
                pAttrib = pAttrib->Next();

            }


        }

        if (pParm->FirstChildElement("rotate")) {
            TiXmlAttribute *pAttrib = pParm->FirstChildElement("rotate")->FirstAttribute();
            while (pAttrib) {
                if (!strcmp(pAttrib->Name(), "angle")) {
                    rotateA = pAttrib->Value();
                    rotate.angle = atof(rotateA);

                } else if (!strcmp(pAttrib->Name(), "axisX")) {
                    rotateX = pAttrib->Value();
                    rotate.x = atof(rotateX);

                } else if (!strcmp(pAttrib->Name(), "axisY")) {
                    rotateY = pAttrib->Value();
                    rotate.y = atof(rotateY);
                } else if (!strcmp(pAttrib->Name(), "axisZ")) {
                    rotateZ = pAttrib->Value();
                    rotate.z = atof(rotateZ);

                } else if (!strcmp(pAttrib->Name(), "T")) {
                rotateT = pAttrib->Value();
                rotate.time = atof(rotateT);
            }

                pAttrib = pAttrib->Next();

            }

        }


        if (pParm->FirstChildElement("scale")) {
            TiXmlAttribute *pAttrib = pParm->FirstChildElement("scale")->FirstAttribute();
            while (pAttrib) {
                if (!strcmp(pAttrib->Name(), "X")) {
                    scaleX = pAttrib->Value();
                    scale.x = atof(scaleX);

                } else if (!strcmp(pAttrib->Name(), "Y")) {
                    scaleY = pAttrib->Value();
                    scale.y = atof(scaleY);
                } else if (!strcmp(pAttrib->Name(), "Z")) {
                    scaleZ = pAttrib->Value();
                    scale.z = atof(scaleZ);
                }

                pAttrib = pAttrib->Next();

            }
        }


        if (pParm->FirstChildElement("orbit")) {
            TiXmlAttribute *pAttrib = pParm->FirstChildElement("orbit")->FirstAttribute();
            while (pAttrib) {
                if (!strcmp(pAttrib->Name(), "Rmaior")) {
                    afelio = pAttrib->Value();
                    orbit.Rmaior = atof(afelio);

                } else if (!strcmp(pAttrib->Name(), "Rmenor")) {
                    perelio = pAttrib->Value();
                    orbit.Rmenor = atof(perelio);
                }
                else if (!strcmp(pAttrib->Name(), "Angle")) {
                    angle = pAttrib->Value();
                    orbit.angle = atof(angle);
                }

                pAttrib = pAttrib->Next();

            }
        }

        if (pParm->FirstChildElement("color")) {
            TiXmlAttribute *pAttrib = pParm->FirstChildElement("color")->FirstAttribute();
            while (pAttrib) {
                if (!strcmp(pAttrib->Name(), "R")) {
                    r = pAttrib->Value();
                    color.push_back(atof(r));

                }
                else if (!strcmp(pAttrib->Name(), "G")) {
                    g = pAttrib->Value();
                    color.push_back(atof(g));
                }
                else if (!strcmp(pAttrib->Name(), "B")) {
                    b = pAttrib->Value();
                    color.push_back(atof(b));
                }

                pAttrib = pAttrib->Next();
            }
        }

        if (pParm->FirstChildElement("models")) {

            pFilho = pParm->FirstChildElement("models");

            if (pFilho) {

                pModels = pFilho->FirstChildElement("model");

                while (pModels) {
                    name = pModels->Attribute("file");

                    modelos.push_back(name);

                    pModels = pModels->NextSiblingElement("model");
                }

            }

        }

        pFilhosGrupo = pParm->FirstChildElement("group");

        while(pFilhosGrupo) {
            Group x = getGroups(pFilhosGrupo,file_name);

            grupo.groups.push_back(x);
            pFilhosGrupo= pFilhosGrupo->NextSiblingElement();
        }

        grupo.translate = translate;
        grupo.rotate = rotate;
        grupo.scale = scale;
        grupo.models = modelos;
        grupo.orbit = orbit;
        grupo.color = color;



    }
    return grupo;

}

vector<Group> parseAll(char const *file_name){
    vector<Group> grupos;
    TiXmlDocument doc(file_name);

    if(doc.LoadFile()) {
        TiXmlElement *pRoot, *pParm;
        pRoot = doc.FirstChildElement("scene");
        if (pRoot) {
            pParm = pRoot->FirstChildElement("group");

            while (pParm) {

                Group x = getGroups(pParm, file_name);
                grupos.push_back(x);
                pParm = pParm->NextSiblingElement();
            }

        }
    }
    else {
        printf("Impossível de ler o ficheiro!");
    }
    return grupos;
}

vector<float> parserFicheiroModels (vector<string> models){
    ifstream myReadFile;
    vector<float> v;

    for(int j=0 ; j< models.size() ; j++) {
        myReadFile.open(models[j].c_str());

        string output;
        float x, y, z;
        char *pEnd;
        int i = 0;

        if (myReadFile.is_open()) {

            while (!myReadFile.eof()) {

                getline(myReadFile, output);

                if (i != 0) {
                    const char *str = output.c_str();
                    x = strtof(str, &pEnd);
                    y = strtof(pEnd, &pEnd);
                    z = strtof(pEnd, NULL);
                    v.push_back(x);
                    v.push_back(y);
                    v.push_back(z);
                }
                i++;
            }
        }

        myReadFile.close();
    }
    return v;
}