#include<stdio.h>
#include<stdlib.h>

#define _USE_MATH_DEFINES
#include <math.h>
#include <vector>

#include <IL/il.h>

#ifdef __APPLE__
#include <GLUT/glut.h>
#else
#include <GL/glew.h>
#include <GL/glut.h>
#endif


#include "parser.h"

vector<Group> grupos;

float alfa = 0.0f, beta = 0.5f, radius = 100.0f;
float camX, camY, camZ;
#define POINT_COUNT 16
float p[POINT_COUNT][3];
float t=0;

float timebase = 0;
int frame = 0;

int mostraOrbita=1, mostraTextura=1, mostraVisao=1; //Boleanos para os menus

float y[3]={0,1,0};

unsigned int texture;
int imageWidth = 256;
unsigned char *imageData;
std::vector<float> position,normal, texCoord;
GLuint buffers[3];

void multMatrixVector(float *m, float *v, float *res) {

    for (int j = 0; j < 4; ++j) {
        res[j] = 0;
        for (int k = 0; k < 4; ++k) {
            res[j] += v[k] * m[j * 4 + k];
        }
    }

}
void spherical2Cartesian() {

    camX = radius * cos(beta) * sin(alfa);
    camY = radius * sin(beta);
    camZ = radius * cos(beta) * cos(alfa);
}


// returns res = a x b
void cross(float *a, float *b, float *res) {

    res[0] = a[1]*b[2] - a[2]*b[1];
    res[1] = a[2]*b[0] - a[0]*b[2];
    res[2] = a[0]*b[1] - a[1]*b[0];
}

// normalizes vector a
void normalize(float *a) {

    float l = sqrt(a[0]*a[0] + a[1] * a[1] + a[2] * a[2]);
    a[0] = a[0]/l;
    a[1] = a[1]/l;
    a[2] = a[2]/l;
}

float h(int i, int j) {

    return(imageData[i*imageWidth + j] * 0.2f);
}

void computeNormal(int i, int j) {

    // fill the normal vector with the normal for vertex at grid location (i,j)
    float v1[3];
    float v2[3];
    float *res1 = (float*)malloc(sizeof(float)*3);

    v1[0] = 0;
    v1[1] = h(i,j+1) - h(i,j-1);
    v1[2] = 2;
    v2[0] = 2;
    v2[1] = h(i+1,j)-h(i-1,j);
    v2[2] = 0;

    cross(v1,v2,res1);
    normalize(res1);

    normal.push_back(res1[0]);
    normal.push_back(res1[1]);
    normal.push_back(res1[2]);
}

void buildRotMatrix(float *x, float *y, float *z, float *m) {

    m[0] = x[0]; m[1] = x[1]; m[2] = x[2]; m[3] = 0;
    m[4] = y[0]; m[5] = y[1]; m[6] = y[2]; m[7] = 0;
    m[8] = z[0]; m[9] = z[1]; m[10] = z[2]; m[11] = 0;
    m[12] = 0; m[13] = 0; m[14] = 0; m[15] = 1;
}

void getCatmullRomPoint(float t, float *p0, float *p1, float *p2, float *p3, float *pos, float *deriv) {
    // catmull-rom matrix
    float m[4][4] = {	{-0.5f,  1.5f, -1.5f,  0.5f},
                         { 1.0f, -2.5f,  2.0f, -0.5f},
                         {-0.5f,  0.0f,  0.5f,  0.0f},
                         { 0.0f,  1.0f,  0.0f,  0.0f}};

    float vectort[4]= {pow(t,3),pow(t,2),t,1};

    float vectord[4]= {3*pow(t,2),2*t,1,0};

    float px[4]={*p0,*p1,*p2,*p3};
    float py[4]={*(p0+1),*(p1+1),*(p2+1),*(p3+1)};
    float pz[4]={*(p0+2),*(p1+2),*(p2+2),*(p3+2)};

    float ax[4];
    float ay[4];
    float az[4];

    multMatrixVector((float *)m,px,ax);

    pos[0]= vectort[0]*ax[0] + vectort[1]*ax[1] +vectort[2]*ax[2] + vectort[3]*ax[3];

    deriv[0]= vectord[0]*ax[0] + vectord[1]*ax[1] +vectord[2]*ax[2]+ vectord[3]*ax[3];

    multMatrixVector((float *)m,py,ay);

    pos[1]= vectort[0]*ay[0] + vectort[1]*ay[1] +vectort[2]*ay[2]+ vectort[3]*ay[3];

    deriv[1]= vectord[0]*ay[0] + vectord[1]*ay[1] +vectord[2]*ay[2]+ vectord[3]*ay[3];

    multMatrixVector((float *)m,pz,az);

    pos[2]= vectort[0]*az[0] + vectort[1]*az[1] +vectort[2]*az[2]+ vectort[3]*az[3];

    deriv[2]= vectord[0]*az[0] + vectord[1]*az[1] +vectord[2]*az[2]+ vectord[3]*az[3];

}

// given  global t, returns the point in the curve
void getGlobalCatmullRomPoint(float gt, float *pos, float *deriv) {

    float t = gt * POINT_COUNT; // this is the real global t
    int index = floor(t);  // which segment
    t = t - index; // where within  the segment

    // indices store the points
    int indices[4];
    indices[0] = (index + POINT_COUNT-1)%POINT_COUNT;
    indices[1] = (indices[0]+1)%POINT_COUNT;
    indices[2] = (indices[1]+1)%POINT_COUNT;
    indices[3] = (indices[2]+1)%POINT_COUNT;

    getCatmullRomPoint(t, p[indices[0]], p[indices[1]], p[indices[2]], p[indices[3]], pos, deriv);
}

void drawOrbitas(Orbit orbitas){
    float white[4] = { 1.0f, 1.0f, 1.0f, 1.0f };
    glMaterialfv(GL_FRONT, GL_AMBIENT_AND_DIFFUSE, white);

    float pos[3];
    float deriv[3];
        float a = orbitas.Rmaior;
        float b = orbitas.Rmenor;
        float delta = 0;

        //Calcula pontos de controlo
        for(int i=0;i<POINT_COUNT;i++){
            float raio = a*b / sqrt(pow(a,2)*pow(sin(delta),2)+pow(b,2)*pow(cos(delta),2));
            float x = raio*cos(delta);
            float z = raio*sin(delta);
            p[i][0]=x;
            p[i][1]=0;
            p[i][2]=z;
            delta+=(22.5*2*M_PI)/360;
        }


        //DESENHAR AS CURVAS
    if(mostraOrbita) {
        glBegin(GL_LINE_LOOP);

        for (float gt = 0; gt < 1; gt += 0.0005) {
            getGlobalCatmullRomPoint(gt, pos, deriv);
            glColor3f(1.0f, 1.0f, 1.0f);
            glVertex3f(pos[0], pos[1], pos[2]);

        }
        glEnd();
    }
 }

void drawFigures(vector<float> v, vector<float> color) {
    float array[4]={color[0],color[1],color[2],1.0f};
    glMaterialfv(GL_FRONT_AND_BACK, GL_AMBIENT_AND_DIFFUSE, array);

    GLuint  buffer;
    GLuint  vertexCount=v.size()/3;

    glGenBuffers(1, &buffer);
    glBindBuffer(GL_ARRAY_BUFFER,buffer);
    glBufferData(GL_ARRAY_BUFFER, sizeof(float) * vertexCount * 3, &(v[0]),GL_STATIC_DRAW);

    glVertexPointer(3,GL_FLOAT,0,0);
    glDrawArrays(GL_TRIANGLES, 0, vertexCount);

}

void renderCometa(vector<float> v, vector<float> color, float time){
    float deriv[3];
    float z[3];
    float pos[3];
    static float elapsed_time=0;

    elapsed_time = glutGet(GLUT_ELAPSED_TIME);
    getGlobalCatmullRomPoint(1/(time*1000)*elapsed_time, pos, deriv);
    // z é o vetor perpendicular aos vetores deriv e up
    cross(deriv, y, z);
    normalize(z);


    cross(z, deriv, y);
    normalize(y);

    normalize(deriv);

    float m[16];

    buildRotMatrix(deriv, y, z, m);
    glMultMatrixf(m);
    glRotatef(-90,1.0,0.0,0.0);

    drawFigures(v,color);
}



void drawGroup(Group grupo) {
    float pos[3];
    float deriv[3];
    float elapsed_time;

    vector<float> v = parserFicheiroModels(grupo.models);

        glPushMatrix();

    if (mostraVisao) {glRotatef(grupo.orbit.angle,0,0,1);}

            glTranslatef(grupo.translate.x,grupo.translate.y,grupo.translate.z);

            if(grupo.orbit.Rmaior!=0 && grupo.orbit.Rmenor!=0) {

                elapsed_time = glutGet(GLUT_ELAPSED_TIME);

                drawOrbitas(grupo.orbit);

                if(grupo.translate.time!=0){

                    getGlobalCatmullRomPoint(1/(grupo.translate.time*1000)*elapsed_time, pos, deriv);

                    glTranslatef(pos[0], pos[1], pos[2]);
                }

                else glTranslatef(grupo.translate.x,grupo.translate.y,grupo.translate.z);

            }

            glScalef(grupo.scale.x, grupo.scale.y, grupo.scale.z);

            for(int i=0 ; i < grupo.groups.size(); i++){
                drawGroup(grupo.groups[i]);

            }


            if(grupo.rotate.time > 0){
                float time = grupo.rotate.time;

                elapsed_time = glutGet(GLUT_ELAPSED_TIME);
                glRotatef(grupo.rotate.angle,0,0,1);
                glRotatef((360/(time*1000))*elapsed_time,grupo.rotate.x,grupo.rotate.y,grupo.rotate.z);
             }

            if(grupo.rotate.time == 0)  glRotatef(grupo.rotate.angle,grupo.rotate.x,grupo.rotate.y,grupo.rotate.z);


            if(grupo.rotate.time < 0) {
                renderCometa(v,grupo.color,grupo.translate.time);
            }
            else {
                drawFigures(v, grupo.color);
            }

    glPopMatrix();
}

void drawAllGroup(){

    for(int i=0 ; i < grupos.size(); i++){
        drawGroup(grupos[i]);
    }
}


void prepareCube() {
    int r=0;
    for (int i = 1; i < imageWidth - 2; i++) {
        for (int j = 1; j < imageWidth - 1; j++) {

            computeNormal(i + 1, j);

            texCoord.push_back((i+1)*0.01);
            r++;
            texCoord.push_back(j*0.01);
            r++;


            position.push_back(i - imageWidth*0.5f + 1);
            position.push_back(0);
            position.push_back(j - imageWidth*0.5f);

            computeNormal(i, j);

            texCoord.push_back(i*0.01);
            r++;
            texCoord.push_back(j*0.01);
            r++;

            position.push_back(i - imageWidth*0.5f);
            position.push_back(0);
            position.push_back(j - imageWidth*0.5f);
        }
    }
    glGenBuffers(3, buffers);

    glBindBuffer(GL_ARRAY_BUFFER, buffers[0]);
    glBufferData(GL_ARRAY_BUFFER, position.size() * sizeof(float), &(position[0]), GL_STATIC_DRAW);

    glBindBuffer(GL_ARRAY_BUFFER, buffers[1]);
    glBufferData(GL_ARRAY_BUFFER, normal.size() * sizeof(float), &(normal[0]), GL_STATIC_DRAW);

    glBindBuffer(GL_ARRAY_BUFFER, buffers[2]);
    glBufferData(GL_ARRAY_BUFFER, texCoord.size() * sizeof(float), &(texCoord[0]), GL_STATIC_DRAW);

    glEnableClientState(GL_VERTEX_ARRAY);
    glEnableClientState(GL_NORMAL_ARRAY);
    glEnableClientState(GL_TEXTURE_COORD_ARRAY);

}


void rendercube(){
    glBindTexture(GL_TEXTURE_2D, texture);
    glBindBuffer(GL_ARRAY_BUFFER, buffers[0]);
    glVertexPointer(3, GL_FLOAT, 0, 0);

    glBindBuffer(GL_ARRAY_BUFFER, buffers[1]);
    glNormalPointer(GL_FLOAT, 0, 0);

    glBindBuffer(GL_ARRAY_BUFFER, buffers[2]);
    glTexCoordPointer(2, GL_FLOAT, 0, 0);

    for (int i = 1; i < imageWidth - 2; i++) {
        glDrawArrays(GL_TRIANGLE_STRIP, (imageWidth - 2) * 2 * i, (imageWidth - 2) * 2);
    }
    glBindTexture(GL_TEXTURE_2D, 0);


}

void drawCube(){
    float white[4] = { 1.0f, 1.0f, 1.0f, 1.0f };
    glMaterialfv(GL_FRONT, GL_AMBIENT_AND_DIFFUSE, white);

    glPushMatrix();

        glPushMatrix();
            glTranslatef(0.0,-((imageWidth/2)-2),0.0);
            rendercube();
        glPopMatrix();

        glPushMatrix();
            glTranslatef(0.0,((imageWidth/2)-2),0.0);
            rendercube();
        glPopMatrix();

        glPushMatrix();
            glTranslatef(0.0,0.0,-((imageWidth/2)-2));
            glRotatef(180.0-90.0,1.0,0.0,0.0);
            rendercube();
        glPopMatrix();

        glPushMatrix();
            glTranslatef(0.0,0.0,((imageWidth/2)-2));
            glRotatef(180.0-90.0,1.0,0.0,0.0);
            rendercube();
        glPopMatrix();

        glPushMatrix();
            glTranslatef(((imageWidth/2)-2),0.0,0.0);
            glRotatef(180.0+90.0,0.0,0.0,1.0);
            rendercube();
        glPopMatrix();

        glPushMatrix();
            glTranslatef(-((imageWidth/2)-2),0.0,0.0);
            glRotatef(180+90.0,0.0,0.0,1.0);
            rendercube();
        glPopMatrix();
    glPopMatrix();
}

void renderScene(void) {

    float fps;
    int time;
    char s[64];

    glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

    glLoadIdentity();
    gluLookAt(camX, camY, camZ,
              0,0,0,
              0.0f,1.0f,0.0f);

    float lpos[4] = { 1,1,1,0 };
    glLightfv(GL_LIGHT0, GL_POSITION, lpos);

    if(mostraTextura) {drawCube();}

    frame++;
    time = glutGet(GLUT_ELAPSED_TIME);
    if (time - timebase > 1000) {
        fps = frame*1000.0 / (time - timebase);
        timebase = time;
        frame = 0;
        sprintf(s, "FPS: %2.6f", fps);
        glutSetWindowTitle(s);
    }

    drawAllGroup();

    t+=0.001;

    glutSwapBuffers();
}

void loadTexture() {

    unsigned int t, tw, th;
    unsigned char *texData;
    ilGenImages(1, &t);
    ilBindImage(t);
    ilLoadImage((ILstring)"space.jpg");
    tw = ilGetInteger(IL_IMAGE_WIDTH);
    th = ilGetInteger(IL_IMAGE_HEIGHT);
    ilConvertImage(IL_RGBA, IL_UNSIGNED_BYTE);
    texData = ilGetData();

    glGenTextures(1, &texture);

    glBindTexture(GL_TEXTURE_2D, texture);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT);

    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR_MIPMAP_LINEAR);

    glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA, tw, th, 0, GL_RGBA, GL_UNSIGNED_BYTE, texData);
    glGenerateMipmap(GL_TEXTURE_2D);
}

void init() {

    unsigned int ima[1];

    ilInit();
    ilGenImages(1, ima);
    ilBindImage(ima[0]);
    ilLoadImage((ILstring)"terreno3.jpg");
    ilConvertImage(IL_LUMINANCE, IL_UNSIGNED_BYTE);

    imageWidth = ilGetInteger(IL_IMAGE_HEIGHT);
    imageData = ilGetData();
    prepareCube();
    loadTexture();

    glEnable(GL_TEXTURE_2D);


    glEnable(GL_DEPTH_TEST);
    glEnable(GL_LIGHTING);
    glEnable(GL_LIGHT0);
}


void changeSize(int w, int h) {

    if(h == 0)
        h = 1;


    float ratio = w * 1.0 / h;


    glMatrixMode(GL_PROJECTION);
    glLoadIdentity();

    glViewport(0, 0, w, h);

    gluPerspective(45.0f ,ratio, 1.0f ,1000.0f);

    glMatrixMode(GL_MODELVIEW);
}


void processSpecialKeys(int key, int xx, int yy) {

    switch (key) {

        case GLUT_KEY_RIGHT:
            alfa -= 0.1; break;

        case GLUT_KEY_LEFT:
            alfa += 0.1; break;

        case GLUT_KEY_UP:
            beta += 0.1f;
            if (beta > 1.5f)
                beta = 1.5f;
            break;

        case GLUT_KEY_DOWN:
            beta -= 0.1f;
            if (beta < -1.5f)
                beta = -1.5f;
            break;

        case GLUT_KEY_PAGE_DOWN: radius -= 20.0f;
            if (radius < 1.0f)
                radius = 1.0f;
            break;

        case GLUT_KEY_PAGE_UP: radius += 20.0f; break;
    }
    spherical2Cartesian();
    glutPostRedisplay();

}

void processMenuEvents(int option) {
    switch (option) {
        case 1:
            glPolygonMode(GL_FRONT_AND_BACK, GL_LINE);
            break;
        case 2:
            glPolygonMode(GL_FRONT_AND_BACK, GL_FILL);
            break;
        case 3:
            if(mostraOrbita) mostraOrbita=0;
            else mostraOrbita=1;
            break;
        case 4:
            if(mostraTextura) mostraTextura=0;
            else mostraTextura=1;
            break;
        case 5:
            if(mostraVisao) mostraVisao=0;
            break;
        case 6:
            if(!mostraVisao) mostraVisao=1;
            break;
        default:
            break;
    }

    glutPostRedisplay();
}

void menus() {

    int menu;


    menu = glutCreateMenu(processMenuEvents);

    glutAddMenuEntry("SEE WIRED", 1);
    glutAddMenuEntry("SEE SOLID", 2);
    glutAddMenuEntry("ORBITS", 3);
    glutAddMenuEntry("TEXTURES", 4);
    glutAddMenuEntry("NORMAL VISION", 5);
    glutAddMenuEntry("REALISTIC VISION", 6);

    glutAttachMenu(GLUT_RIGHT_BUTTON);
}

int main(int argc, char **argv) {

    glutInit(&argc, argv);
    glutInitDisplayMode(GLUT_DEPTH|GLUT_DOUBLE|GLUT_RGBA);
    glutInitWindowPosition(100,100);
    glutInitWindowSize(800,800);
    glutCreateWindow("Fase-II");
    glClearColor(0, 0, 0, 0);

    grupos = parseAll(argv[1]);


    //glPolygonMode( GL_FRONT_AND_BACK, GL_LINE);
    glutDisplayFunc(renderScene);
    glutIdleFunc(renderScene);
    glutReshapeFunc(changeSize);


    glutSpecialFunc(processSpecialKeys);
    menus();


    if(!mostraTextura){
        glEnable(GL_DEPTH_TEST);
        glEnable(GL_CULL_FACE);
        glEnableClientState(GL_VERTEX_ARRAY);
    }

    spherical2Cartesian();

    #ifndef __APPLE__   
    glewInit();
#endif  
    if(mostraTextura) init();

    glutMainLoop();


    return 1;
}
