#include "generator.h"
#include <math.h>

int plane(float size, char* file_name){
    FILE *fp;
    fp = fopen(file_name, "w");
    float x = size/2;   
    fprintf(fp, "%d", 6);
    fprintf(fp, "\n%.2f 0.0 %.2f", -x, -x);
    fprintf(fp, "\n%.2f 0.0 %.2f", -x, x);
    fprintf(fp, "\n%.2f 0.0 %.2f", x, x);
    fprintf(fp, "\n%.2f 0.0 %.2f", x, x);
    fprintf(fp, "\n%.2f 0.0 %.2f", x, -x);
    fprintf(fp, "\n%.2f 0.0 %.2f", -x, -x);
    
    fclose(fp);

    return 0;
}

int cone(float radius,float height, int slices,int stacks,char* file_name){
    FILE *fp;
    fp = fopen(file_name, "w");
    
    float variacao = 2*M_PI /slices;
    float h_camada_cons = height /stacks; //altura de cada camada -> constante
    float var_raio = radius/ stacks;

    float h_camada_baixo = 0;
    float h_camada_cima = h_camada_cons;
    float radius_baixo = radius;
    float radius_cima = radius - var_raio;

    int npontos = slices*3 + 2*(stacks-1)*3*slices + slices*3;

    fprintf(fp,"%d", npontos);
    float alfa = 0.0;

    int contador=0;
    
    for (int i = 0; i < slices; ++i){
        fprintf(fp, "\n0.0 0.0 0.0");
        fprintf(fp, "\n%.2f 0.0 %.2f", radius*sin(alfa+variacao), radius*cos(alfa+variacao));
        fprintf(fp, "\n%.2f 0.0 %.2f", radius*sin(alfa), radius*cos(alfa));
        alfa += variacao;
        contador= contador+3;
    }

    for (int i = 0; i < stacks; ++i){
        alfa = 0;
        for (int j = 0; j < slices; ++j){

            if(i < stacks -1){ //Para nao formar triangulos uns em cima dos outros na ultima camada
            fprintf(fp, "\n%.2f %.2f %.2f", radius_baixo*sin(alfa), h_camada_baixo,radius_baixo*cos(alfa));
            fprintf(fp, "\n%.2f %.2f %.2f", radius_cima*sin(alfa+variacao), h_camada_cima,radius_cima*cos(alfa+variacao));
            fprintf(fp, "\n%.2f %.2f %.2f", radius_cima*sin(alfa), h_camada_cima,radius_cima*cos(alfa));
            contador = contador+3;
            }
            
            fprintf(fp, "\n%.2f %.2f %.2f", radius_baixo*sin(alfa), h_camada_baixo,radius_baixo*cos(alfa));
            fprintf(fp, "\n%.2f %.2f %.2f", radius_baixo*sin(alfa+variacao), h_camada_baixo,radius_baixo*cos(alfa+variacao));
            fprintf(fp, "\n%.2f %.2f %.2f", radius_cima*sin(alfa+variacao), h_camada_cima,radius_cima*cos(alfa+variacao));

            contador=contador+3;

            alfa += variacao;
        }
        h_camada_baixo += h_camada_cons;
        h_camada_cima += h_camada_cons;
        radius_baixo -= var_raio;
        radius_cima -= var_raio;
    }
    return 0;

}

int sphere(float radius, int slices,int stacks,char* file_name){
    FILE *fp;
    fp = fopen(file_name,"w");

    int npontos = slices*3 *2*stacks;


    float variacao_alfa = 2*M_PI /slices;
    float variacao_beta = (M_PI) / stacks;

    float beta= -(M_PI/2);

    float h_camada_baixo = radius*sin(beta);
    float h_camada_cima = radius*sin(beta+variacao_beta);
    float radius_baixo = radius*cos(beta);
    float radius_cima = radius*cos(beta+variacao_beta);

    fprintf(fp,"%d", npontos);
    float alfa = 0.0;

    for (int i = 0; i <= stacks; ++i){
        alfa = 0;
        for (int j = 0; j < slices; ++j){
            fprintf(fp, "\n%.2f %.2f %.2f", radius_baixo * sin(alfa), h_camada_baixo, radius_baixo * cos(alfa));
            fprintf(fp, "\n%.2f %.2f %.2f", radius_baixo * sin(alfa + variacao_alfa), h_camada_baixo, radius_baixo * cos(alfa + variacao_alfa));
            fprintf(fp, "\n%.2f %.2f %.2f", radius_cima * sin(alfa + variacao_alfa), h_camada_cima, radius_cima * cos(alfa + variacao_alfa));



            fprintf(fp, "\n%.2f %.2f %.2f", radius_cima*sin(alfa+variacao_alfa), h_camada_cima,radius_cima*cos(alfa+variacao_alfa));
            fprintf(fp, "\n%.2f %.2f %.2f", radius_cima*sin(alfa), h_camada_cima,radius_cima*cos(alfa));
            fprintf(fp, "\n%.2f %.2f %.2f", radius_baixo*sin(alfa), h_camada_baixo,radius_baixo*cos(alfa));


            alfa += variacao_alfa;
        }
        beta+=variacao_beta;
        h_camada_baixo = h_camada_cima;
        h_camada_cima = radius*sin(beta);
        radius_baixo = radius_cima;
        radius_cima = radius*cos(beta);

    }
    return 0;
}

int cintura_asteroides(float radius, int slices,int stacks, int n_asteroides, char* file_name){

    FILE *fp;
    fp = fopen(file_name, "w");

    int npontos = slices*3 *2*stacks*n_asteroides;

    float x,z=0;

    float variacao_alfa = 2*M_PI /slices;
    float variacao_beta = (M_PI) / stacks;
    float beta= -(M_PI/2);
    float h_camada_baixo;
    float h_camada_cima;
    float radius_baixo;
    float radius_cima;

    fprintf(fp,"%d", npontos);
    float alfa = 0.0;

    srand(6800);

    for (int k = 0; k < n_asteroides; k++) {
        beta = -M_PI/2;
        h_camada_baixo = radius*sin(beta);
        h_camada_cima = radius*sin(beta+variacao_beta);
        radius_baixo = radius*cos(beta);
        radius_cima = radius*cos(beta+variacao_beta);

        while (sqrt(x * x + z * z) < 20 || (sqrt(x * x + z * z) > 22)) {
            x = ((float) rand() / RAND_MAX) * 200 - 100;
            z = ((float) rand() / RAND_MAX) * 200 - 100;
        }
        
        for (int i = 0; i <= stacks; ++i) {
            alfa = 0;
            for (int j = 0; j < slices; ++j) {
                fprintf(fp, "\n%.2f %.2f %.2f",radius_baixo * sin(alfa)+x, h_camada_baixo, radius_baixo * cos(alfa)+z);
                fprintf(fp, "\n%.2f %.2f %.2f",radius_baixo * sin(alfa + variacao_alfa)+x, h_camada_baixo, radius_baixo * cos(alfa + variacao_alfa)+z);
                fprintf(fp, "\n%.2f %.2f %.2f",radius_cima * sin(alfa + variacao_alfa)+x, h_camada_cima, radius_cima * cos(alfa + variacao_alfa)+z);


                fprintf(fp, "\n%.2f %.2f %.2f",radius_cima * sin(alfa + variacao_alfa)+x, h_camada_cima, radius_cima * cos(alfa + variacao_alfa)+z);
                fprintf(fp, "\n%.2f %.2f %.2f",radius_cima * sin(alfa)+x, h_camada_cima, radius_cima * cos(alfa)+z);
                fprintf(fp, "\n%.2f %.2f %.2f",radius_baixo * sin(alfa)+x, h_camada_baixo, radius_baixo * cos(alfa)+z);


                alfa += variacao_alfa;
            }
            beta += variacao_beta;
            h_camada_baixo = h_camada_cima;
            h_camada_cima = radius * sin(beta);
            radius_baixo = radius_cima;
            radius_cima = radius * cos(beta);

        }
        x=0;
        z=0;

    }
    return 0;
}

void box(float x,float y,float z,int n_dimensions,char* file_name){
    FILE *fp;
    fp = fopen(file_name, "w");

    float z_medida = z / 2;
    float y_medida = y / 2;
    float x_medida = x / 2;

    float variacao_x = x / n_dimensions;
    float variacao_y = y / n_dimensions;
    float variacao_z = z / n_dimensions;

    float z_array[5] = {z_medida, z_medida, -z_medida, -z_medida, z_medida};
    float x_array[5] = {-x_medida, x_medida, x_medida, -x_medida, -x_medida};

    float x_antes;
    float x_depois;
    float z_antes;
    float z_depois;
    float y_antes;
    float y_depois;
    int i = 0;

    int npontos = 6* (n_dimensions * n_dimensions * 2) * 3;
    fprintf(fp, "%d", npontos);

    for (int i = 0; i < 4; i++) {
        y_depois = -y_medida;

        for (int j = 0; j < n_dimensions; j++) {
            y_antes = y_depois;
            y_depois = y_antes + variacao_y;
            x_antes = x_array[i];
            x_depois = x_array[i];
            z_antes = z_array[i];
            z_depois = z_array[i];

            for (int k = 0; k < n_dimensions; k++) {
                if (i == 0) {
                    x_antes = x_depois;
                    x_depois = x_depois + variacao_x;
                }
                if (i == 1) {
                    z_antes = z_depois;
                    z_depois = z_depois - variacao_z;
                }
                if (i == 2) {
                    x_antes = x_depois;
                    x_depois = x_depois - variacao_x;
                }
                if (i == 3) {
                    z_antes = z_depois;
                    z_depois = z_depois + variacao_z;
                }

                fprintf(fp, "\n%.2f %.2f %.2f", x_antes, y_antes,z_antes);
                fprintf(fp, "\n%.2f %.2f %.2f", x_depois, y_antes, z_depois);
                fprintf(fp, "\n%.2f %.2f %.2f", x_antes, y_depois, z_antes);

                fprintf(fp, "\n%.2f %.2f %.2f", x_antes, y_depois, z_antes);
                fprintf(fp, "\n%.2f %.2f %.2f", x_depois, y_antes, z_depois);
                fprintf(fp, "\n%.2f %.2f %.2f", x_depois, y_depois, z_depois);
            }
        }
    }

    x_antes = x_array[0];
    x_depois = x_array[0];
    z_antes = z_array[0];
    z_depois = z_array[0];


    for (int i = 0; i < n_dimensions; i++) {
        z_antes = z_depois;
        z_depois = z_depois - variacao_z;
        x_depois = x_array[0];
        for (int k = 0; k < n_dimensions; k++) {
            x_antes = x_depois;
            x_depois = x_depois + variacao_x;

            fprintf(fp, "\n%.2f %.2f %.2f", x_antes, y_medida, z_antes);
            fprintf(fp, "\n%.2f %.2f %.2f", x_depois, y_medida, z_antes);
            fprintf(fp, "\n%.2f %.2f %.2f", x_antes, y_medida, z_depois);

            fprintf(fp, "\n%.2f %.2f %.2f", x_antes, y_medida, z_depois);
            fprintf(fp, "\n%.2f %.2f %.2f", x_depois, y_medida, z_antes);
            fprintf(fp, "\n%.2f %.2f %.2f", x_depois, y_medida, z_depois);

            fprintf(fp, "\n%.2f %.2f %.2f", x_depois, -y_medida, z_antes);
            fprintf(fp, "\n%.2f %.2f %.2f", x_antes, -y_medida, z_antes);
            fprintf(fp, "\n%.2f %.2f %.2f", x_antes, -y_medida, z_depois);

            fprintf(fp, "\n%.2f %.2f %.2f", x_depois, -y_medida, z_antes);
            fprintf(fp, "\n%.2f %.2f %.2f", x_antes, -y_medida, z_depois);
            fprintf(fp, "\n%.2f %.2f %.2f", x_depois, -y_medida, z_depois);

        }


    }

}


void torus(float ri, float re, int slices,int stacks,char* file_name){
    FILE *fp;
    fp = fopen(file_name, "w");

    fprintf(fp, "0");
    float radius_mae = ri+((re-ri)/2);
    float var_alfa_mae = 2*M_PI /slices;
    float alfa_mae = 0.0;
    float z_mae_anterior = 0.0;
    float x_mae_anterior = 0.0;
    float z_mae_posterior = 0.0;
    float x_mae_posterior = 0.0;


    float radius_filho= (re-ri)/2;
    float var_alfa_filho= 2*M_PI /(stacks*2);
    float alfa_filho = 0.0;
    float z_filho_anteriorA = 0.0;
    float y_filho_anteriorA = 0.0;
    float x_filho_anteriorA = 0.0;

    float z_filho_posteriorA = 0.0;
    float y_filho_posteriorA = 0.0;
    float x_filho_posteriorA = 0.0;

    float z_filho_anteriorP = 0.0;
    float y_filho_anteriorP = 0.0;
    float x_filho_anteriorP = 0.0;

    float z_filho_posteriorP = 0.0;
    float y_filho_posteriorP = 0.0;
    float x_filho_posteriorP = 0.0;


    for (int i = 0; i < slices; ++i){
        z_mae_anterior = radius_mae*cos(alfa_mae);
        x_mae_anterior = radius_mae*sin(alfa_mae);
        z_mae_posterior = radius_mae*cos(alfa_mae + var_alfa_mae);
        x_mae_posterior = radius_mae*sin(alfa_mae + var_alfa_mae);

        //printf("%f\n", x_mae_anterior);

        for (int j=0;j < (stacks*2);++j){
            //circunferencia anterior
            z_filho_anteriorA = z_mae_anterior+radius_filho*cos(alfa_filho)*cos(alfa_mae);
            y_filho_anteriorA = radius_filho*sin(alfa_filho);
            x_filho_anteriorA = x_mae_anterior + radius_filho*cos(alfa_filho)*sin(alfa_mae);

            z_filho_posteriorA = z_mae_anterior + radius_filho*cos(alfa_filho + var_alfa_filho)*cos(alfa_mae);
            y_filho_posteriorA = radius_filho*sin(alfa_filho+var_alfa_filho);
            x_filho_posteriorA = x_mae_anterior + radius_filho*cos(alfa_filho + var_alfa_filho)*sin(alfa_mae);

            //circunferencia posterior
            z_filho_anteriorP = z_mae_posterior + radius_filho*cos(alfa_filho)*cos(alfa_mae + var_alfa_mae);
            y_filho_anteriorP = radius_filho*sin(alfa_filho);
            x_filho_anteriorP = x_mae_posterior + radius_filho*cos(alfa_filho)*sin(alfa_mae + var_alfa_mae);

            z_filho_posteriorP = z_mae_posterior + radius_filho*cos(alfa_filho + var_alfa_filho)*cos(alfa_mae + var_alfa_mae);
            y_filho_posteriorP = radius_filho*sin(alfa_filho+var_alfa_filho);
            x_filho_posteriorP = x_mae_posterior + radius_filho*cos(alfa_filho + var_alfa_filho)*sin(alfa_mae + var_alfa_mae);

            fprintf(fp, "\n%.2f %.2f %.2f", x_filho_anteriorA,y_filho_anteriorA, z_filho_anteriorA);
            /*ponto posterior*/fprintf(fp, "\n%.2f %.2f %.2f", x_filho_anteriorP,y_filho_anteriorP, z_filho_anteriorP);
            fprintf(fp, "\n%.2f %.2f %.2f", x_filho_posteriorA,y_filho_posteriorA, z_filho_posteriorA);

            /*ponto posterior*/fprintf(fp, "\n%.2f %.2f %.2f", x_filho_posteriorA,y_filho_posteriorA, z_filho_posteriorA);
            fprintf(fp, "\n%.2f %.2f %.2f", x_filho_anteriorP,y_filho_anteriorP, z_filho_anteriorP);
            fprintf(fp, "\n%.2f %.2f %.2f", x_filho_posteriorP,y_filho_posteriorP, z_filho_posteriorP);

            alfa_filho += var_alfa_filho;
        }
        alfa_filho = 0.0;
        alfa_mae += var_alfa_mae;


    }
}

float** multMatrixMatrix(int L1, int C1, float ** m1, int L2, int C2, float ** m2) {

    float **res = (float**)malloc(L1 * sizeof(float*)); //Aloca um Vetor de Ponteiros
    float soma=0;

    for (int i = 0; i < L1; i++) { //Percorre as linhas do Vetor de Ponteiros
        res[i] = (float *) malloc(C2 * sizeof(float)); //Aloca um Vetor de Inteiros para cada posição do Vetor de Ponteiros.
        for (int j = 0; j < C2; j++) { //Percorre o Vetor de Inteiros atual.
            res[i][j] = 0; //Inicializa com 0.
        }
    }

    for (int l1 = 0; l1 < L1; l1++) {
        for (int c2 = 0; c2 < C2; c2++) {
            for (int l2 = 0; l2 < L2; l2++) {
                soma += m1[l1][l2]*m2[l2][c2];
            }
            res[l1][c2] = soma;
            soma = 0;
        }
    }

    return res;

}

//Dividir um vetor de floats numa matriz
void vectorToMatrixX(vector<float> vec, int divisions, float ** res){
    int ndiv = divisions;
    int l=0, c=0, j=0;
    for(int i=0 ; i< vec.size(); i++){
        if(j==ndiv && i%3==0) {
            ndiv += divisions;
            l=0;
            c++;
            j++;
            res[l][c]=vec[i];
            l++;
        }

        else if(i%3==0){
            j++;
            res[l][c]=vec[i];
            l++;
        }
    }
}

void vectorToMatrixY(vector<float> vec, int divisions, float ** res){
    int ndiv = divisions;
    int l=0, c=0, j=0;

    for(int i=0 ; i< vec.size(); i++){
        if(j==ndiv && i%3==1) {
            ndiv +=divisions;
            l=0;
            c++;
            j++;
            res[l][c]=vec[i];
            l++;
        }

        else if(i%3==1){
            j++;
            res[l][c]=vec[i];
            l++;
        }
    }
}

void vectorToMatrixZ(vector<float> vec, int divisions, float ** res){
    int ndiv = divisions;
    int l=0, c=0, j=0;

    for(int i=0 ; i< vec.size(); i++){
        if(j==ndiv && i%3==2) {
            ndiv +=divisions;
            l=0;
            c++;
            j++;
            res[l][c]=vec[i];
            l++;
        }

        else if(i%3==2){
            j++;
            res[l][c]=vec[i];
            l++;
        }
    }
}

void matrixTranspose(int L, int C, float ** m, float ** res) {
    for(int l=0; l<L; l++){
        for(int c=0; c<C; c++){
            res[c][l]=m[l][c];
        }
    }
}

void matrixInit(int L,int C, float** m){

    for (int i = 0; i < L; i++) { //Percorre as linhas do Vetor de Ponteiros
        m[i] = (float *) malloc(C * sizeof(float)); //Aloca um Vetor de Inteiros para cada posição do Vetor de Ponteiros.
        for (int j = 0; j < C; j++) { //Percorre o Vetor de Inteiros atual.
            m[i][j] = 0; //Inicializa com 0.
        }
    }
}

void clearMatrix(int L, int C, float** m){
    for(int i=0 ; i<L; i++)
        free(m[i]);

    free(m);
}

// B(u,v) = U * M * Pxyz * M_transposta * V
vector<float>  getBezierPoints(vector<float> patch_pontos, float t1, float t2) {
    vector<float> res;


    float ** M = (float**)malloc(4 * sizeof(float*)); matrixInit(4,4,M);
    float ** Mt = (float**)malloc(4 * sizeof(float*)); matrixInit(4,4,Mt);

    M[0][0]=1;  M[0][1]=0;  M[0][2]=0;  M[0][3]=0;
    M[1][0]=-3; M[1][1]=3;  M[1][2]=0;  M[1][3]=0;
    M[2][0]=3;  M[2][1]=-6; M[2][2]=3;  M[2][3]=0;
    M[3][0]=-1; M[3][1]=3;  M[3][2]=-3; M[3][3]=1;

    float **T1 = (float**)malloc(4 * sizeof(float*)); matrixInit(4,1,T1);

    T1[0][0]= 1.0;
    T1[1][0]= t1;
    T1[2][0]= t1*t1;
    T1[3][0]= t1*t1*t1;

    float **T1t = (float**)malloc(1 * sizeof(float*)); matrixInit(1,4,T1t);

    matrixTranspose(4,1,T1,T1t);

    float **T1M = (float**)malloc(4 * sizeof(float*)); matrixInit(4,1,T1M);

    T1M = multMatrixMatrix(1,4,T1t,4,4,M);


    float **Px = (float**)malloc(4 * sizeof(float*)); matrixInit(4,4,Px);
    float **Py = (float**)malloc(4 * sizeof(float*)); matrixInit(4,4,Py);
    float **Pz = (float**)malloc(4 * sizeof(float*)); matrixInit(4,4,Pz);

    vectorToMatrixX(patch_pontos,4,Px);
    vectorToMatrixY(patch_pontos,4,Py);
    vectorToMatrixZ(patch_pontos,4,Pz);

    float **T1MPx = (float**)malloc(1 * sizeof(float*)); matrixInit(1,4,T1MPx);
    float **T1MPy = (float**)malloc(1 * sizeof(float*)); matrixInit(1,4,T1MPy);
    float **T1MPz = (float**)malloc(1 * sizeof(float*)); matrixInit(1,4,T1MPz);

    T1MPx = multMatrixMatrix(1,4,T1M,4,4,Px);
    T1MPy = multMatrixMatrix(1,4,T1M,4,4,Py);
    T1MPz = multMatrixMatrix(1,4,T1M,4,4,Pz);


    matrixTranspose(4,4,M,Mt);

    float **T2 = (float**)malloc(4 * sizeof(float*)); matrixInit(4,1,T2);

    T2[0][0]= 1;
    T2[1][0]= t2;
    T2[2][0]= t2*t2;
    T2[3][0]= t2*t2*t2;

    float **MtT2 = (float**)malloc(4 * sizeof(float*)); matrixInit(4,1,MtT2);

    MtT2 = multMatrixMatrix(4,4,Mt,4,1,T2);

    float **finalX = (float**)malloc(1 * sizeof(float*)); matrixInit(1,1,finalX);
    float **finalY = (float**)malloc(1 * sizeof(float*)); matrixInit(1,1,finalY);
    float **finalZ = (float**)malloc(1 * sizeof(float*)); matrixInit(1,1,finalZ);

    finalX = multMatrixMatrix(1,4,T1MPx,4,1,MtT2);
    finalY = multMatrixMatrix(1,4,T1MPy,4,1,MtT2);
    finalZ = multMatrixMatrix(1,4,T1MPz,4,1,MtT2);

    res.push_back(finalX[0][0]);
    res.push_back(finalY[0][0]);
    res.push_back(finalZ[0][0]);

    clearMatrix(1,1,finalX);
    clearMatrix(1,1,finalY);
    clearMatrix(1,1,finalZ);
    clearMatrix(4,4,M);
    clearMatrix(4,4,Mt);
    clearMatrix(4,1,MtT2);
    clearMatrix(4,1,T1);
    clearMatrix(1,4,T1M);
    clearMatrix(1,4,T1MPx);
    clearMatrix(1,4,T1MPy);
    clearMatrix(1,4,T1MPz);
    clearMatrix(1,4,T1t);
    clearMatrix(4,1,T2);
    clearMatrix(4,4,Px);
    clearMatrix(4,4,Py);
    clearMatrix(4,4,Pz);

    return res;
}

//Obter pontos, ordenados, de uma certa patch (fornecendo o indice dessa patch, de 0 a nr_patches)
vector<float> getPontosIndices(int indice,vector< vector<int> > *patches , vector<float> *pontos ){
    vector<float> res;
    int pos,pos_pontos;
    for(int i=0; i<(*patches)[indice].size(); i++){
        pos=(*patches)[indice][i];
        pos_pontos=pos*3;
        res.push_back((*pontos)[pos_pontos]);
        res.push_back((*pontos)[pos_pontos+1]);
        res.push_back((*pontos)[pos_pontos+2]);
    }

    return res;
}

void parserFicheiroPatch (const char* filename, vector< vector<int> > *patches , vector<float> *pontos ){
    ifstream myReadFile;
    vector<int> patches_ind;

    myReadFile.open(filename);

    string output;
    float coord;
    int i = 0;
    int patch;

    if (myReadFile.is_open()) {


        while (!myReadFile.eof()) {

            getline(myReadFile, output);

            const char *str = output.c_str();

            if(i==0) {patch=atoi(str);}

            if(i!=0 && i<= patch){
                char* indice = strtok((char *)str," ,");

                while (indice) {
                    patches_ind.push_back(atoi(indice));
                    indice = strtok(NULL, " ,");
                }
                (*patches).push_back(patches_ind);
                patches_ind.clear();
            }

            if(i> patch+1){
                char* indice = strtok((char *)str," ,");

                while (indice) {
                    coord=atof(indice);
                    indice = strtok(NULL, " ,");
                    (*pontos).push_back(coord);
                }

            }

            i++;
        }
    }

    myReadFile.close();
}

void teapot (char*filenamePatch, int tessellation, char* filenameGenerator){

    vector< vector<int> > patches;
    vector<float> pontos;

    parserFicheiroPatch(filenamePatch,&patches,&pontos);

    FILE *fp;
    fp = fopen(filenameGenerator, "w");

    int npontos = (tessellation+1)*(tessellation+1)* patches.size()*6;

    fprintf(fp,"%d", npontos);

    vector<float> patch_pontos;
    float variacao = (1/(float)tessellation);
    float t1,t2;
    vector<float> res;

    for(int a=0; a<patches.size() ; a++) {
        patch_pontos = getPontosIndices(a, &patches, &pontos);

        for (int i = 0; i <= tessellation; i++) {
            for (int j = 0; j <= tessellation; j++) {

                t1 = j * variacao;
                t2 = i * variacao;

                res = getBezierPoints(patch_pontos, t1, t2);
                fprintf(fp, "\n%.2f %.2f %.2f", res[0], res[1], res[2]);

                res = getBezierPoints(patch_pontos, t1+ variacao , t2);
                fprintf(fp, "\n%.2f %.2f %.2f", res[0], res[1], res[2]);

                res = getBezierPoints(patch_pontos, t1, t2 + variacao);
                fprintf(fp, "\n%.2f %.2f %.2f", res[0], res[1], res[2]);

                fprintf(fp, "\n%.2f %.2f %.2f", res[0], res[1], res[2]);

                res = getBezierPoints(patch_pontos, t1+ variacao, t2 );
                fprintf(fp, "\n%.2f %.2f %.2f", res[0], res[1], res[2]);

                res = getBezierPoints(patch_pontos, t1+ variacao, t2+ variacao);
                fprintf(fp, "\n%.2f %.2f %.2f", res[0], res[1], res[2]);
            }
        }
    }
}


int main(int argc, char const *argv[]){

    int erro = 0;
    if(!strcmp(argv[1],"plane")){
//possivel mensagem de erro;        
        if(argc==4){
            plane(atof(argv[2]),(char*)argv[3]);
        }
        else erro = 1;
    }
    if(!strcmp(argv[1],"cone")){
//possivel mensagem de erro;        
        if(argc==7){
            cone(atof(argv[2]),atof(argv[3]),atoi(argv[4]),atoi(argv[5]),(char*)argv[6]);
        }
        else erro = 1;
    }
    if(!strcmp(argv[1],"sphere")){
//possivel mensagem de erro;
        if(argc==6){
            sphere(atof(argv[2]),atoi(argv[3]),atoi(argv[4]),(char*)argv[5]);
        }
        else erro = 1;
    }

    if(!strcmp(argv[1],"box")){
//possivel mensagem de erro;
        if(argc==7){
            box(atof(argv[2]),atof(argv[3]),atof(argv[4]),atoi(argv[5]),(char*)argv[6]);
        }
        else erro = 1;
    }

    if(!strcmp(argv[1],"rocks")){
//possivel mensagem de erro;
        if(argc==7){
            cintura_asteroides(atof(argv[2]),atoi(argv[3]),atoi(argv[4]),atoi(argv[5]),(char*)argv[6]);
        }
        else erro = 1;
    }

    if(!strcmp(argv[1],"torus")){
//possivel mensagem de erro;
        if(argc==7){
            torus(atof(argv[2]),atof(argv[3]),atoi(argv[4]),atoi(argv[5]),(char*)argv[6]);
        }
        else erro = 1;
    }

    if(!strcmp(argv[1],"teapot")){
//possivel mensagem de erro;
        if(argc==5){
            teapot((char*)argv[2],atoi(argv[3]),(char*)argv[4]);
        }
        else erro = 1;
    }

    if (erro) printf("ERRO\n");

    return 0;
}