#include <iostream>
#include <fstream>
#include <string>
#include <stdlib.h>
#include <sstream>
#include <vector>
#include "../tinyxml/tinyxml.h"

using namespace std;


typedef struct ponto{
    float x;
    float y;
    float z;
}Ponto;

void parserFicheiro (const char *filename, vector<Ponto>* v);

vector<string> getModels(char const *file_name);
