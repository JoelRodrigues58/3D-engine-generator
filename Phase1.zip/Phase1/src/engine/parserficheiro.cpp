#include "parseficheiro.h"



vector<string> getModels(char const *file_name){

    vector<string> models;
	TiXmlDocument doc(file_name);

	string name;
	if(doc.LoadFile()) {
		TiXmlElement *pRoot, *pParm;
		pRoot = doc.FirstChildElement("scene");
		if (pRoot) {
			pParm = pRoot->FirstChildElement("model");
			while (pParm) {
				name = pParm->Attribute("file");

				models.push_back(name);

				pParm = pParm->NextSiblingElement("model");
			}
		}
	}
	else {
		printf("Impossível de ler o ficheiro!");
	}
	return models;
}




//Passar os Pontos para um vetor de Pontos
void parserFicheiro (const char* filename, vector<Ponto> *v){
	ifstream myReadFile;
 	myReadFile.open(filename);
 	string output;
 	float x,y,z;
 	char* pEnd;
	int i=0;

 	if (myReadFile.is_open()) {

 		while (!myReadFile.eof()) {

				Ponto coord;
				getline(myReadFile, output);

            if(i!=0){
				const char *str = output.c_str();
				x = strtof(str, &pEnd);
				y = strtof(pEnd, &pEnd);
				z = strtof(pEnd, NULL);
				coord.x = x;
				coord.y = y;
				coord.z = z;
                (*v).push_back(coord);

			}
			i++;
		}
	}

	myReadFile.close();

}
