#ifdef __APPLE__
#include <GLUT/glut.h>
#else
#include <GL/glut.h>
#endif

#define _USE_MATH_DEFINES
#include <math.h>
#include "parseficheiro.h"

vector<Ponto> v;

float px,py,pz=10.0;
float dx,dy,dz =0.0;
float angulo1=0;
float angulo2=0;
float raio=10;


void changeSize(int w, int h) {
	// Prevent a divide by zero, when window is too short
	// (you cant make a window with zero width).
	if(h == 0)
		h = 1;

	// compute window's aspect ratio 
	float ratio = w * 1.0 / h;

	// Set the projection matrix as current
	glMatrixMode(GL_PROJECTION);
	// Load Identity Matrix
	glLoadIdentity();
	
	// Set the viewport to be the entire window
    glViewport(0, 0, w, h);

	// Set perspective
	gluPerspective(45.0f ,ratio, 1.0f ,1000.0f);

	// return to the model view matrix mode
	glMatrixMode(GL_MODELVIEW);
}



void drawFigures(void) {
	int i =0;
    glBegin(GL_TRIANGLES);

	while(i< v.size()) {
        glColor3f(1.0f, 0.0f, 0.0f);
        glVertex3f(v[i].x,v[i].y, v[i].z);
        glColor3f(0.0f, 1.0f, 0.0f);
        glVertex3f(v[i + 1].x, v[i + 1].y, v[i + 1].z);
        glColor3f(0.0f, 0.0f, 1.0f);
        glVertex3f(v[i + 2].x, v[i + 2].y, v[i + 2].z);
        i += 3;
	}
    glEnd();
    
}


void renderScene(void) {

	// clear buffers
	glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

	// set the camera
	glLoadIdentity();
    gluLookAt(px,py,pz,
              dx,dy,dz,
              0.0f,1.0f,0.0f);

	drawFigures();


    glBegin(GL_LINES);
    // Eixo X
    glVertex3f(-20, 0, 0);
    glVertex3f(20, 0, 0);

    // Eixo Y
    glVertex3f(0, -20, 0);
    glVertex3f(0, 20, 0);

    // Eixo Z
    glVertex3f(0, 0, -20);
    glVertex3f(0, 0, 20);
    glEnd();

    // End of frame
	glutSwapBuffers();
}




void processKeys(unsigned char c, int xx, int yy) {

    {
        switch (c){
            case 'a':
                angulo1 -= 0.125 * M_PI;
                px = raio*sin(angulo1);
                pz = raio*cos(angulo1);
                break;
            case 'd':
                angulo1 +=0.125 * M_PI;
                px = raio*sin(angulo1);
                pz = raio*cos(angulo1);
                break;

            case 'w':
                angulo2 -= 0.125 * M_PI;
                py = raio * sin(angulo2);
                pz = raio * cos(angulo2);
                break;

            case 's':
                angulo2 += 0.125 * M_PI;
                py = raio * sin(angulo2);
                pz = raio * cos(angulo2);
                break;

            default:
                break;
        }
        glutPostRedisplay();
    }

}


int main(int argc, char **argv) {

    vector<string> models = getModels(argv[1]);
    int i=0;

	while(i<models.size()){

            parserFicheiro(models[i].c_str(),&v);

        i++;

    }

// init GLUT and the window
	glutInit(&argc, argv);
	glutInitDisplayMode(GLUT_DEPTH|GLUT_DOUBLE|GLUT_RGBA);
	glutInitWindowPosition(100,100);
	glutInitWindowSize(800,800);
	glutCreateWindow("CG@DI-UM");
    glClearColor(1, 1, 1, 0);


// Required callback registry
    glPolygonMode( GL_FRONT_AND_BACK, GL_LINE);
	glutDisplayFunc(renderScene);
	glutReshapeFunc(changeSize);

// Callback registration for keyboard processing
    glutKeyboardFunc(processKeys);

//  OpenGL settings
	glEnable(GL_DEPTH_TEST);
	glEnable(GL_CULL_FACE);
	
// enter GLUT's main cycle
	glutMainLoop();
	
	return 1;
}
