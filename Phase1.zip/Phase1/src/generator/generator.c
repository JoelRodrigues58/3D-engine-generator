#include "generator.h"
#include <math.h>

int plane(float size, char* file_name){
	FILE *fp;
	fp = fopen(file_name, "w");
	float x = size/2;	
	fprintf(fp, "%d", 6);
	fprintf(fp, "\n%.2f 0.0 %.2f", -x, -x);
	fprintf(fp, "\n%.2f 0.0 %.2f", -x, x);
	fprintf(fp, "\n%.2f 0.0 %.2f", x, x);
	fprintf(fp, "\n%.2f 0.0 %.2f", x, x);
	fprintf(fp, "\n%.2f 0.0 %.2f", x, -x);
	fprintf(fp, "\n%.2f 0.0 %.2f", -x, -x);
	
	fclose(fp);

	return 0;
}

int cone(float radius,float height, int slices,int stacks,char* file_name){
	FILE *fp;
	fp = fopen(file_name, "w");
	
	float variacao = 2*M_PI /slices;
	float h_camada_cons = height /stacks; //altura de cada camada -> constante
	float var_raio = radius/ stacks;

	float h_camada_baixo = 0;
	float h_camada_cima = h_camada_cons;
	float radius_baixo = radius;
	float radius_cima = radius - var_raio;

	int npontos = slices*3 + 2*(stacks-1)*3*slices + slices*3;

	fprintf(fp,"%d", npontos);
	float alfa = 0.0;

	int contador=0;
	
	for (int i = 0; i < slices; ++i){
		fprintf(fp, "\n0.0 0.0 0.0");
		fprintf(fp, "\n%.2f 0.0 %.2f", radius*sin(alfa+variacao), radius*cos(alfa+variacao));
		fprintf(fp, "\n%.2f 0.0 %.2f", radius*sin(alfa), radius*cos(alfa));
		alfa += variacao;
		contador= contador+3;
	}

	for (int i = 0; i < stacks; ++i){
		alfa = 0;
		for (int j = 0; j < slices; ++j){

			if(i < stacks -1){ //Para nao formar triangulos uns em cima dos outros na ultima camada
			fprintf(fp, "\n%.2f %.2f %.2f", radius_baixo*sin(alfa), h_camada_baixo,radius_baixo*cos(alfa));
			fprintf(fp, "\n%.2f %.2f %.2f", radius_cima*sin(alfa+variacao), h_camada_cima,radius_cima*cos(alfa+variacao));
			fprintf(fp, "\n%.2f %.2f %.2f", radius_cima*sin(alfa), h_camada_cima,radius_cima*cos(alfa));
			contador = contador+3;
			}
			
			fprintf(fp, "\n%.2f %.2f %.2f", radius_baixo*sin(alfa), h_camada_baixo,radius_baixo*cos(alfa));
			fprintf(fp, "\n%.2f %.2f %.2f", radius_baixo*sin(alfa+variacao), h_camada_baixo,radius_baixo*cos(alfa+variacao));
			fprintf(fp, "\n%.2f %.2f %.2f", radius_cima*sin(alfa+variacao), h_camada_cima,radius_cima*cos(alfa+variacao));

			contador=contador+3;

			alfa += variacao;
		}
		h_camada_baixo += h_camada_cons;
		h_camada_cima += h_camada_cons;
		radius_baixo -= var_raio;
		radius_cima -= var_raio;
	}
	return 0;

}


int sphere(float radius, int slices,int stacks,char* file_name){
	FILE *fp;
	fp = fopen(file_name, "w");

	int npontos = slices*3 *2*stacks;

	stacks = stacks/2;

	float variacao_alfa = 2*M_PI /slices;
	float variacao_beta = (M_PI / 2) / stacks;

	float beta= 0.0;

	float h_camada_baixo = 0;
	float h_camada_cima = radius*sin(beta);
	float radius_baixo = radius;
	float radius_cima = radius*cos(beta);

	fprintf(fp,"%d", npontos);
	float alfa = 0.0;


	int contador=0;

	for (int i = 0; i <=stacks; ++i){
		alfa = 0;
		for (int j = 0; j < slices; ++j){

            if( i< stacks){
                fprintf(fp, "\n%.2f %.2f %.2f", radius_baixo*sin(alfa),h_camada_baixo,radius_baixo*cos(alfa));
                fprintf(fp, "\n%.2f %.2f %.2f", radius_cima*sin(alfa+variacao_alfa),h_camada_cima,radius_cima*cos(alfa+variacao_alfa));
                fprintf(fp, "\n%.2f %.2f %.2f", radius_cima*sin(alfa), h_camada_cima,radius_cima*cos(alfa));

                fprintf(fp, "\n%.2f %.2f %.2f", radius_cima*sin(alfa), -h_camada_cima,radius_cima*cos(alfa));
                fprintf(fp, "\n%.2f %.2f %.2f", radius_cima*sin(alfa+variacao_alfa), -h_camada_cima,radius_cima*cos(alfa+variacao_alfa));
                fprintf(fp, "\n%.2f %.2f %.2f", radius_baixo*sin(alfa), -h_camada_baixo,radius_baixo*cos(alfa));
                contador=contador+6;
            }

            fprintf(fp, "\n%.2f %.2f %.2f", radius_baixo*sin(alfa), h_camada_baixo,radius_baixo*cos(alfa));
            fprintf(fp, "\n%.2f %.2f %.2f", radius_baixo*sin(alfa+variacao_alfa),h_camada_baixo,radius_baixo*cos(alfa+variacao_alfa));
            fprintf(fp, "\n%.2f %.2f %.2f", radius_cima*sin(alfa+variacao_alfa), h_camada_cima,radius_cima*cos(alfa+variacao_alfa));


            fprintf(fp, "\n%.2f %.2f %.2f", radius_cima*sin(alfa+variacao_alfa), -h_camada_cima,radius_cima*cos(alfa+variacao_alfa));
            fprintf(fp, "\n%.2f %.2f %.2f", radius_baixo*sin(alfa+variacao_alfa), -h_camada_baixo,radius_baixo*cos(alfa+variacao_alfa));
            fprintf(fp, "\n%.2f %.2f %.2f", radius_baixo*sin(alfa), -h_camada_baixo,radius_baixo*cos(alfa));

			contador=contador+6;

			alfa += variacao_alfa;
		}
		beta+=variacao_beta;
		h_camada_baixo = h_camada_cima;
		h_camada_cima = radius*sin(beta);
		radius_baixo = radius_cima;
		radius_cima = radius*cos(beta);

	}
	return 0;

}
void box(float x,float y,float z,int n_dimensions,char* file_name){
    FILE *fp;
    fp = fopen(file_name, "w");

    float z_medida = z / 2;
    float y_medida = y / 2;
    float x_medida = x / 2;

    float variacao_x = x / n_dimensions;
    float variacao_y = y / n_dimensions;
    float variacao_z = z / n_dimensions;

    float z_array[5] = {z_medida, z_medida, -z_medida, -z_medida, z_medida};
    float x_array[5] = {-x_medida, x_medida, x_medida, -x_medida, -x_medida};

    float x_antes;
    float x_depois;
    float z_antes;
    float z_depois;
    float y_antes;
    float y_depois;
    int i = 0;

    int npontos = 6* (n_dimensions * n_dimensions * 2) * 3;
    fprintf(fp, "%d", npontos);

    for (int i = 0; i < 4; i++) {
        y_depois = -y_medida;

        for (int j = 0; j < n_dimensions; j++) {
            y_antes = y_depois;
            y_depois = y_antes + variacao_y;
            x_antes = x_array[i];
            x_depois = x_array[i];
            z_antes = z_array[i];
            z_depois = z_array[i];

            for (int k = 0; k < n_dimensions; k++) {
                if (i == 0) {
                    x_antes = x_depois;
                    x_depois = x_depois + variacao_x;
                }
                if (i == 1) {
                    z_antes = z_depois;
                    z_depois = z_depois - variacao_z;
                }
                if (i == 2) {
                    x_antes = x_depois;
                    x_depois = x_depois - variacao_x;
                }
                if (i == 3) {
                    z_antes = z_depois;
                    z_depois = z_depois + variacao_z;
                }

                fprintf(fp, "\n%.2f %.2f %.2f", x_antes, y_antes,z_antes);
                fprintf(fp, "\n%.2f %.2f %.2f", x_depois, y_antes, z_depois);
                fprintf(fp, "\n%.2f %.2f %.2f", x_antes, y_depois, z_antes);

                fprintf(fp, "\n%.2f %.2f %.2f", x_antes, y_depois, z_antes);
                fprintf(fp, "\n%.2f %.2f %.2f", x_depois, y_antes, z_depois);
                fprintf(fp, "\n%.2f %.2f %.2f", x_depois, y_depois, z_depois);
            }
        }
    }

    x_antes = x_array[0];
    x_depois = x_array[0];
    z_antes = z_array[0];
    z_depois = z_array[0];


    for (int i = 0; i < n_dimensions; i++) {
        z_antes = z_depois;
        z_depois = z_depois - variacao_z;
        x_depois = x_array[0];
        for (int k = 0; k < n_dimensions; k++) {
            x_antes = x_depois;
            x_depois = x_depois + variacao_x;

            fprintf(fp, "\n%.2f %.2f %.2f", x_antes, y_medida, z_antes);
            fprintf(fp, "\n%.2f %.2f %.2f", x_depois, y_medida, z_antes);
            fprintf(fp, "\n%.2f %.2f %.2f", x_antes, y_medida, z_depois);

            fprintf(fp, "\n%.2f %.2f %.2f", x_antes, y_medida, z_depois);
            fprintf(fp, "\n%.2f %.2f %.2f", x_depois, y_medida, z_antes);
            fprintf(fp, "\n%.2f %.2f %.2f", x_depois, y_medida, z_depois);

            fprintf(fp, "\n%.2f %.2f %.2f", x_depois, -y_medida, z_antes);
            fprintf(fp, "\n%.2f %.2f %.2f", x_antes, -y_medida, z_antes);
            fprintf(fp, "\n%.2f %.2f %.2f", x_antes, -y_medida, z_depois);

            fprintf(fp, "\n%.2f %.2f %.2f", x_depois, -y_medida, z_antes);
            fprintf(fp, "\n%.2f %.2f %.2f", x_antes, -y_medida, z_depois);
            fprintf(fp, "\n%.2f %.2f %.2f", x_depois, -y_medida, z_depois);

        }


    }

}

int main(int argc, char const *argv[]){

	int erro = 0;
	if(!strcmp(argv[1],"plane")){
//possivel mensagem de erro;		
		if(argc==4){
			plane(atof(argv[2]),(char*)argv[3]);
		}
		else erro = 1;
	}
	if(!strcmp(argv[1],"cone")){
//possivel mensagem de erro;		
		if(argc==7){
			cone(atof(argv[2]),atof(argv[3]),atoi(argv[4]),atoi(argv[5]),(char*)argv[6]);
		}
		else erro = 1;
	}
	if(!strcmp(argv[1],"sphere")){
//possivel mensagem de erro;
		if(argc==6){
			sphere(atof(argv[2]),atoi(argv[3]),atoi(argv[4]),(char*)argv[5]);
		}
		else erro = 1;
	}

    if(!strcmp(argv[1],"box")){
//possivel mensagem de erro;
        if(argc==7){
            box(atof(argv[2]),atof(argv[3]),atof(argv[4]),atoi(argv[5]),(char*)argv[6]);
        }
        else erro = 1;
    }



    if (erro) printf("ERRO\n");

	return 0;
}